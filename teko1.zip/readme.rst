

###################
What is TEKO
###################

TEKO is a digital electronics component marketplace, and TEKO has many feature to market your IoT Project such as bid, rent out, and sell. We will develop untill the whole system is suitable for many people who need it most.

*******************
Release Information
*******************

This repo contains in-development code for future releases. To see updated release, you can watch this repo, or if you want to visit demo, you can go with it
<https://teko.my.id>`_ page.

**************************
Changelog and New Features
**************************

Simple email registration and Authentication, edit profile, email forgot password, email invoice seller and buyer and more will be added like bid and rent.

*******************
Server Requirements
*******************

PHP version 5.6 or newer is recommended.

It should work on 5.3.7 as well, but we strongly advise you NOT to run
such old versions of PHP, because of potential security and performance
issues, as well as missing features.

************
Installation
************

download or clone, and put it in htdocs xampp, or www in wamp, and voila it will work :) but unfortunately I won't give you our database today, because that's still private.

# TekoMarketplace
 Using codeigniter, php, html, js, jquery, bootstrap4, and sbadmin2 and still under development
 
# Disclosure
 Honestly and Unfortunately I don't want to upload my sql database, because this is my private project, so you can see the output of this project on this link:
https://teko.my.id

if you don't see any (success) page (e.g., the icon is dissapeared or show blank icon) just refresh the page,

*******
License
*******

Please see the `license
agreement <https://github.com/bcit-ci/CodeIgniter/blob/develop/user_guide_src/source/license.rst>`_.

*********
Resources
*********

-  `User Guide <https://codeigniter.com/docs>`_
-  `Language File Translations <https://github.com/bcit-ci/codeigniter3-translations>`_
-  `Community Forums <http://forum.codeigniter.com/>`_
-  `Community Wiki <https://github.com/bcit-ci/CodeIgniter/wiki>`_
-  `Community Slack Channel <https://codeigniterchat.slack.com>`_
- `SB ADMIN 2 Startbootstrap`
- Idcloudhost.com


Report security issues to our `Security Panel <mailto:security@codeigniter.com>`_
or via our `page on HackerOne <https://hackerone.com/codeigniter>`_, thank you.

***************
Acknowledgement
***************

TEKO team -> Alfian Firmansyah as Fullstack developer

