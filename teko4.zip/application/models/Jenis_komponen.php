<?php

class Jenis_komponen extends CI_Model
{
    public function tampil_data()
    {
        return $this->db->get('komponen');
    }

    public function tampil_data_2()
    {
        $email = $this->session->userdata('email');
        $query = "SELECT `k`.`id_komponen`,`nama_komponen`,`manufacture`,`deskripsi`,`kategori`,`harga`,`stok`,`k`.`image`,`k`.`date_created` FROM `komponen` `k`, `user` `u`, `jual` `j`
        WHERE `u`.`id` = `j`.`id_customer` AND `k`.`id_komponen` = `j`.`id_komponen` AND `u`.`email` = '$email'";
        //memanggil data dari dalam database untuk kemudian ditampilkan
        return $this->db->query($query);
    }

    public function ambil_id_komponen()
    {
        // query untuk ambil jual dan insert
        // $id_id = $this->session->userdata('id');
        // $query = "SELECT `id_komponen` FROM `komponen`
        // WHERE `id_customer` = $id_id LIMIT 1";
        // $conv = $this->db->query($query);
        // return $record = $conv->row_array();

        $id = $this->db->insert_id();
        return $id;
    }


    public function tambah_komponen($data, $table)
    {
        $this->db->insert($table, $data);
    }
    public function edit_komponen($where, $table)
    {
        return $this->db->get_where($table, $where);
    }
    public function update_data($where, $data, $table)
    {
        $this->db->where($where);
        $this->db->update($table, $data);
    }
    public function hapus_data($where, $table)
    {
        $this->db->where($where);
        $this->db->delete($table);
    }
    public function find($id)
    {
        //record data berdasarkan id
        $result = $this->db->where('id_komponen', $id)
            ->limit(1)
            ->get('komponen');
        if ($result->num_rows() > 0) {
            return $result->row();
        } else {
            return array();
        }
    }

    public function detail_komponen($id_komponen)
    {
        $result = $this->db->where('id_komponen', $id_komponen)->get('komponen');
        if ($result->num_rows() > 0) {
            return $result->result();
        } else {
            return false;
        }
    }
}
