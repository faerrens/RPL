<?php
class Model_kategori extends CI_Model
{
    public function data_komponen_pasif()
    {
        //membaut querynya, kalo kita menampilkan data semua cukup get, namun kalo ingin membuat kategori harus pake get where
        return $this->db->get_where("komponen", array('kategori' => 'Komponen Pasif'));
    }
    public function data_komponen_aktif()
    {
        //membaut querynya, kalo kita menampilkan data semua cukup get, namun kalo ingin membuat kategori harus pake get where
        return $this->db->get_where("komponen", array('kategori' => 'Komponen Aktif'));
    }
    public function data_project_market()
    {
        //membaut querynya, kalo kita menampilkan data semua cukup get, namun kalo ingin membuat kategori harus pake get where
        return $this->db->get_where("komponen", array('kategori' => 'Project IoT (Market)'));
    }
    public function data_project_auction()
    {
        //membaut querynya, kalo kita menampilkan data semua cukup get, namun kalo ingin membuat kategori harus pake get where
        return $this->db->get_where("komponen", array('kategori' => 'Project IoT (Auction)'));
    }
}
