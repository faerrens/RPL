<?php

class Detail_user extends CI_Model
{

    public function update_detail($where, $data, $table)
    {
        $this->db->where($where);
        $this->db->update($table, $data);
    }
}
