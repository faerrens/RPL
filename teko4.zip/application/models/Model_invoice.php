<?php

class Model_invoice extends CI_Model
{


    public function index()
    {

        //karena ada database yang menggunakan waktu/ datetime setting default timezone jakarta
        date_default_timezone_set('Asia/Jakarta');

        //ini mengambil dari form yang ada di proses_pesanan
        $nama = $this->input->post('nama');
        $alamat = $this->input->post('alamat');
        $invoice = array(
            'nama' => $nama,
            'alamat' => $alamat,
            'tgl_pesan' => date('Y-m-d H:i:s'),
            'batas_bayar' => date('Y-m-d H:i:s', mktime(date('H'), date('i'), date('s'), date('m'), date('d') + 1, date('Y'))),
            'kurir' => $this->input->post('kurir'),
            'status_bayar' => 0



            //menentukan batas bayar supaya cuma bisa 1 hari/24 jam gimana caranya?  itu tadi di date('d') + 1 (ditambah satu) hehe
        );

        //insert ke dalam table invoice

        $this->db->insert('invoice', $invoice);
        $id_invoice = $this->db->insert_id();



        //membuat table pesanan nanti

        foreach ($this->cart->contents() as $item) {
            $data = array(
                'id_invoice' => $id_invoice,
                'id_komponen' => $item['id'],
                'nama_komponen' => $item['name'],
                'jumlah' => $item['qty'],
                'harga' => $item['price'],
                'pilihan' => $this->input->post('pilihan'),
                'id_customer' => $this->session->userdata('id'),
                'id_penjual' => $item['options']['id_penjual'],
                'resi' => 0

            );

            //memasukkan ke table pesanan

            $this->db->insert('pesanan', $data);
        }
        return true;
    }

    public function tampil_data()
    {
        $result = $this->db->get('invoice');
        if ($result->num_rows() > 0) {
            return $result->result();
        } else {
            return false;
        }
    }

    public function tampil_data_2()
    {
        $id_c = $this->session->userdata('id');
        $query = "SELECT * FROM `invoice` `i`, `pesanan` `p`, `user` `u` WHERE `i`.`id` = `p`.`id_invoice` AND `u`.`id` = `p`.`id_customer` AND `u`.`id` = $id_c ORDER BY `i`.`id` DESC";
        //memanggil data dari dalam database untuk kemudian ditampilkan
        $result = $this->db->query($query);
        if ($result->num_rows() > 0) {
            return $result->result();
        } else {
            return false;
        }
    }


    public function ambil_id_invoice($id_invoice)
    {
        $result = $this->db->where('id', $id_invoice)->limit(1)->get('invoice');
        if ($result->num_rows() > 0) {
            return $result->row();
        } else {
            return false;
        }
    }
    public function ambil_id_pesanan($id_invoice)
    {
        $result = "SELECT * FROM pesanan WHERE id_invoice = $id_invoice";
        $result = $this->db->query($result);

        if ($result->num_rows() > 0) {
            return $result->result();
        } else {
            return false;
        }
    }
}
