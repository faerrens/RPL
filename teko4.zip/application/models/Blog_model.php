<?php
class Blog_model extends CI_Model
{

    function get_all_blog()
    {
        $result = $this->db->get('komponen');
        return $result;
    }

    function search_blog($title)
    {
        $this->db->like('nama_komponen', $title, 'both');
        $this->db->order_by('id_komponen', 'ASC');
        $this->db->limit(10);
        return $this->db->get('komponen')->result();
    }
}
