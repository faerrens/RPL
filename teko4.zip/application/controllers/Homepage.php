<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Homepage extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
    }

    public function index()
    {
        //buat batesin karakter ambil load helper code igniter fungsinya word_limiter()
        $this->load->helper('text');

        //judul atas
        $data['title'] = 'TEKO - Tempat Jual-Beli Segala Komponen Digital Elektronik dan IoT';
        $data['komponen'] = $this->jenis_komponen->tampil_data()->result();
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['user_role'] = $this->db->get_where('user_role', ['id' => $this->session->userdata('id')])->row_array();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/homepage_sidebar', $data);
        $this->load->view('templates/homepage_topbar', $data);
        $this->load->view('homepage/index', $data);
        $this->load->view('templates/homepage_footer', $data);
    }

    public function test()
    {
        //buat batesin karakter ambil load helper code igniter fungsinya word_limiter()
        $this->load->helper('text');

        //judul atas
        $data['title'] = 'TEKO - Tempat Jual-Beli Segala Komponen Digital Elektronik dan IoT';
        $data['komponen'] = $this->jenis_komponen->tampil_data()->result();
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['user_role'] = $this->db->get_where('user_role', ['id' => $this->session->userdata('id')])->row_array();
        $this->load->view('templates/header', $data);
        $this->load->view('homepage/test', $data);
        $this->load->view('templates/homepage_footer', $data);
    }

    public function tambah_ke_keranjang($id)
    {
        $komponen = $this->jenis_komponen->find($id);

        $query = "SELECT `jual`.`id_customer` FROM `jual`,`komponen` WHERE `jual`.`id_komponen` = `komponen`.`id_komponen` AND `komponen`.`id_komponen` = $komponen->id_komponen";
        $go = $this->db->query($query)->row();



        //ini ngambil dari dokumentasi Code igniter untuk shopping cart
        $data = array(
            'id'      => $komponen->id_komponen,
            'qty'     => 1,
            'price'   => $komponen->harga,
            'name'    => $komponen->nama_komponen,
            'options' => array('id_penjual' => $go->id_customer)

        );

        $this->cart->insert($data);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Item kamu berhasil ditambahkan ke keranjang! <a class="badge badge-info p-2" href="' . base_url('homepage/detail_keranjang') . '">Lihat Keranjang kamu</a></div>');
        redirect('homepage');
    }

    public function tambah_ke_keranjang_2($id)
    {
        $komponen = $this->jenis_komponen->find($id);
        $query = "SELECT `jual`.`id_customer` FROM `jual`,`komponen` WHERE `jual`.`id_komponen` = `komponen`.`id_komponen` AND `komponen`.`id_komponen` = $komponen->id_komponen";
        $go = $this->db->query($query)->row();

        //ini ngambil dari dokumentasi Code igniter untuk shopping cart
        $data = array(
            'id'      => $komponen->id_komponen,
            'qty'     => 1,
            'price'   => $komponen->harga,
            'name'    => $komponen->nama_komponen,
            'options' => array('id_penjual' => $go->id_customer)
        );

        $this->cart->insert($data);
        redirect('homepage/detail_keranjang');
    }

    public function tambah_quantities($id)
    {
        $komponen = $this->jenis_komponen->find($id);
        $qty = $this->input->post('qty');
        $rowid = $this->input->post('rowid');

        //ini ngambil dari dokumentasi Code igniter untuk shopping cart
        $data = array(
            'rowid'      => $rowid,
            'qty'     => $qty,

        );

        $this->cart->update($data);
        redirect('homepage/detail_keranjang');
    }

    public function detail_keranjang()
    {
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['user_role'] = $this->db->get_where('user_role', ['id' => $this->session->userdata('id')])->row_array();

        $data['title'] = 'Detail Keranjang';
        $data['komponen'] = $this->jenis_komponen->tampil_data()->result();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/homepage_sidebar', $data);
        $this->load->view('templates/homepage_topbar', $data);
        $this->load->view('homepage/keranjang');
        $this->load->view('templates/footer', $data);
    }

    public function hapus_keranjang()
    {
        $this->cart->destroy();
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Keranjang berhasil dikosongkan!</div>');
        redirect('homepage');
    }

    public function pembayaran()
    {
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['detail_user'] = $this->db->get_where('detail_user', ['email' => $this->session->userdata('email')])->row_array();
        $data['user_role'] = $this->db->get_where('user_role', ['id' => $this->session->userdata('id')])->row_array();

        $data['title'] = 'Pembayaran';
        $data['komponen'] = $this->jenis_komponen->tampil_data()->result();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/homepage_sidebar', $data);
        $this->load->view('templates/homepage_topbar', $data);
        $this->load->view('homepage/pembayaran', $data);
        $this->load->view('templates/footer', $data);
    }

    public function bayar($id, $token)
    {
        //fungsi untuk memverifikasi untuk link yang dikirm ke email

        //mengubah is_active kalo email dan token bener

        //ambil emailnya sama tokennya dulu dari gmail url


        //pastikan emailnya valid
        $user = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        //kalo ada usernya

        if ($user) {
            //kalo ada user email di database, query di tabel user token, ada nggak tokennya
            $user_token = $this->db->get_where('user_token', ['token' => $token])->row_array();

            if ($user_token) {

                //untuk waktu validasi
                if (time() - $user_token['date_created'] < (60 * 60 * 24)) { //jika waktu daftar kurang dari 1 hari maka boleh
                    //kalo berhasil maka ubah isactivenya

                    $ubah = "UPDATE invoice, pesanan SET status_bayar = 1 WHERE invoice.id = pesanan.id_invoice AND pesanan.id_invoice = $id";

                    $this->db->query($ubah);



                    $ambil_id = [
                        'id_invoice' . $id => $id
                    ];

                    $this->session->set_userdata($ambil_id);

                    $select = "SELECT `u`.`email` as email FROM `user` `u`, `pesanan` `p`, `jual` `j`, `invoice` `i`, `komponen` `k` 
                    WHERE `p`.`id_invoice` = `i`.`id` AND `p`.`id_komponen` = `k`.`id_komponen` AND `k`.`id_customer` = `u`.`id` AND `j`.`id_komponen` = `k`.`id_komponen` AND `j`.`id_customer` = `u`.`id` AND `p`.`id_invoice` = $id";
                    $email = $this->db->query($select)->result();

                    foreach ($email as $e) {

                        $this->_sendEmail2($this->session->userdata('id_invoice' . $id), 'seller', $e->email);
                    }

                    //jangan lupa delete user tokennya kan udah gadibutuhin
                    $this->db->delete('user_token', ['email' => $this->session->userdata('email')]);

                    $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Selamat, pesanan kamu sudah berhasil terproses ! Silahkan cek resi di menu invoice No. #' . $id . ', atau klik <a href="' . base_url('user/invoice') . '"><button class="btn btn-sm btn-info">Di sini</button></a> dan search No. ' . $id . '</div>');
                    // var_dump(bayar());
                    // die;
                    redirect('user', 'refresh');
                } else {

                    //hapus usernya dan tokennya, jadinya dia harus daftar ulang selama 24 jam tadi expired
                    $this->db->delete('user', ['email' => $this->session->userdata('email')]);
                    $this->db->delete('user_token', ['email' => $this->session->userdata('email')]);

                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Token Expired!</div>');
                    redirect('homepage');
                }
            } else {
                //kalo tokennya salah

                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Token Invalid</div>');
                redirect('homepage');
            }
        } else {
            //kalo ngga didatabase user ada kasih pesan error aja pke flashdata
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">pembayaran kamu gagal! Login first</div>');
            redirect('homepage');
        }
    }

    public function proses_pesanan()
    {
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['user_role'] = $this->db->get_where('user_role', ['id' => $this->session->userdata('id')])->row_array();

        $data['title'] = 'Pembayaran';


        //apabila datanya diproses maka kita akan panggil model khusus invoice
        $is_processed = $this->model_invoice->index();

        //apabila diproses, maka akan memunculkan viewnya diload, jika data gagal diproses maka pesan gagal aja


        if ($is_processed) {
            $token = base64_encode(random_bytes(32)); //ini masih berupa char-char aneh belum pure alphanumeric
            //maka dari itu diterjemahkan dulu ke alphanumeric supaya dikenali oleh mysql dengan base64

            //siapkan user tokennya untuk tabel penyimpan token

            $user_token = [
                'email' => $this->session->userdata('email'),
                'token' => $token,
                'date_created' => time() //untuk mengexpiredkan token
            ];

            $this->db->insert('user_token', $user_token);



            $this->_sendEmail($token, 'bayar');
            // if (bayar() == true) {
            //     $this->_sendEmail2('seller');
            // } else {
            //     return false;
            // }
            $this->cart->destroy();
            $this->load->view('templates/header', $data);
            $this->load->view('templates/homepage_sidebar', $data);
            $this->load->view('templates/homepage_topbar', $data);
            $this->load->view('homepage/proses_pesanan');
            $this->load->view('templates/footer', $data);
        } else {
            echo "Maaf, Pesanan Anda Gagal diproses";
        }

        //untuk menghapus data
    }

    private function _sendEmail($token, $type)
    {

        $id = $this->cart->contents();

        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['user_role'] = $this->db->get_where('user_role', ['id' => $this->session->userdata('id')])->row_array();

        foreach ($id as $items) {

            $querys = "SELECT *, `k`.`id_customer` AS penjual FROM `user` `u`, `pesanan` `p`, `komponen` `k`, `invoice` `i`, `detail_user` `d`
        WHERE `p`.`id_komponen` = `k`.`id_komponen` AND `p`.`id_customer` = `u`.`id` AND `p`.`id_invoice` = `i`.`id` AND `d`.`id` = `u`.`id` AND `p`.`id_komponen` =" . $items['id'];
        }

        $result = $this->db->query($querys);



        foreach ($result->result() as $q) {


            //pertama konfigurasi dulu
            $config = [
                'protocol' => 'smtp',
                'smtp_host' => 'ssl://mail.teko.my.id',
                'smtp_user' => 'no-reply@teko.my.id',
                'smtp_pass' => 'tekoadmin12345',
                'smtp_port' => 465,
                'mailtype' => 'html',
                'charset' => 'utf-8',
                'newline' => "\r\n" //kalo ngggak pake ini nggak bakal bisa kekirim karena ini sama aja kaya trigger ketika kita mencepet tombol enter
            ];

            $this->load->library('encrypt');
            //panggil librari email di Ci
            //config tadi masuk ke librariy parameter
            $this->load->library('email', $config);

            //harus initialize dulu
            $this->email->initialize($config);

            //dari siapa?
            $this->email->from('no-reply@teko.my.id', 'Tempat Komponen TEKO');
            //mau dikirim kemana?


            if ($type == 'bayar') {
                $this->email->to($q->email);
                $this->email->subject('Hai, lakukan pembayaranmu yuk! No. Invoice: #' . $q->id_invoice);
                //token pake url encode untuk mengubah encoding url yang pake % supaya karakternya gak hilang kalo keluar +

                $content = $this->load->view('homepage/email_content', $token, TRUE);

                $this->email->message($content . 'Klik link ini untuk membayar pesanan kamu sejumlah Rp. ' . number_format($this->cart->total(), 0, ',', '.') . ' :<a href="' . base_url() . 'homepage/payment?id=' . $q->id_invoice . '&token=' . urlencode($token) . '"><button style="color: white; padding: 15px; background-color: #02925d; border-style: none; border-radius: 10px;">Bayar Pakai ' . strtoupper($q->pilihan) . ' Sekarang.</button></a>');
            } else if ($type == 'seller') {

                $select = "SELECT `email` FROM `user` WHERE `id` = $q->penjual";
                $email = $this->db->query($select);

                foreach ($email as $e) {
                    $this->email->to($e->email);
                }

                $this->email->subject('Pembeli dataanggg, cek dulu yuk beli apa..');
                //token pake url encode untuk mengubah encoding url yang pake % supaya karakternya gak hilang kalo keluar +

                $content2 = $this->load->view('homepage/email_content2', '', TRUE);

                $this->email->message($content2 . 'Klik link ini untuk mengisi form resi');
            }
        }
        //untuk kirimnya harus pake if
        if ($this->email->send()) {
            return true;
        } else {
            echo $this->email->print_debugger();
            die;
        }
    }

    public function payment()
    {
        $id = $this->input->get('id');
        $token = $this->input->get('token');
        $password = $this->input->post('password');

        $user = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data = [
            'id' => $id,
            'token' => $token
        ];

        $this->form_validation->set_rules('password', 'Password', 'required|trim|min_length[8]');

        if ($this->form_validation->run() == false) {
            $this->load->view('homepage/payment', $data);
        } else {

            if ($user) {
                //jika usernya ada dan aktif
                if ($user['is_active'] == 1) {
                    // cek passwordnya
                    if (password_verify($password, $user['password'])) {
                        $id2 = $this->input->post('id');
                        $token2 = $this->input->post('token');

                        $this->bayar($id2, $token2);
                    } else {
                        $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Password salah! Keterangan: Maksimal password kamu salah hanya 1x, LINK EXPIRED! maka dari itu, untuk mengulang sesi ini, silakan kembali ke email kamu untuk klik button bayar.</div>');
                        redirect('auth/blocked2');
                    }
                } else {
                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Akunmu bermasalah, silahkan hubungi administrator!</div>');
                    redirect('homepage/payment');
                }
            }
        }
    }




    private function _sendEmail2($id, $type, $email)
    {

        // $id = $this->cart->contents();

        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['user_role'] = $this->db->get_where('user_role', ['id' => $this->session->userdata('id')])->row_array();



        $query = "SELECT *, `k`.`id_customer` AS penjual FROM `user` `u`, `pesanan` `p`, `komponen` `k`, `invoice` `i`, `detail_user` `d`
        WHERE `p`.`id_komponen` = `k`.`id_komponen` AND `p`.`id_customer` = `u`.`id` AND `p`.`id_invoice` = `i`.`id` AND `d`.`id` = `u`.`id` AND p.id_penjual = (SELECT id FROM user WHERE email = '$email') AND `p`.`id_invoice` = $id";

        $result = $this->db->query($query);

        // var_dump($query);
        // die;

        foreach ($result->result() as $q) {


            //pertama konfigurasi dulu
            $config = [
                'protocol' => 'smtp',
                'smtp_host' => 'ssl://mail.teko.my.id',
                'smtp_user' => 'no-reply@teko.my.id',
                'smtp_pass' => 'tekoadmin12345',
                'smtp_port' => 465,
                'mailtype' => 'html',
                'charset' => 'utf-8',
                'newline' => "\r\n" //kalo ngggak pake ini nggak bakal bisa kekirim karena ini sama aja kaya trigger ketika kita mencepet tombol enter
            ];

            $this->load->library('encrypt');
            //panggil librari email di Ci
            //config tadi masuk ke librariy parameter
            $this->load->library('email', $config);

            //harus initialize dulu
            $this->email->initialize($config);

            //dari siapa?
            $this->email->from('no-reply@teko.my.id', 'Tempat Komponen TEKO');
            //mau dikirim kemana?


            if ($type == 'seller') {

                $select = "SELECT group_concat(`u`.`email` separator ',') as email FROM `user` `u`, `pesanan` `p`, `jual` `j`, `invoice` `i`, `komponen` `k` 
                WHERE `p`.`id_invoice` = `i`.`id` AND `p`.`id_komponen` = `k`.`id_komponen` AND `k`.`id_customer` = `u`.`id` AND `j`.`id_komponen` = `k`.`id_komponen` AND `j`.`id_customer` = `u`.`id` AND `p`.`id_invoice` = $id";
                //  $email = $this->db->query($select)->result();

                $select2 = "SELECT `u`.`email` as email FROM `user` `u`, `pesanan` `p`, `jual` `j`, `invoice` `i`, `komponen` `k` 
                WHERE `p`.`id_invoice` = `i`.`id` AND `p`.`id_komponen` = `k`.`id_komponen` AND `k`.`id_customer` = `u`.`id` AND `j`.`id_komponen` = `k`.`id_komponen` AND `j`.`id_customer` = `u`.`id` AND `p`.`id_invoice` = $id";
                $email2 = $this->db->query($select2)->result();





                //  foreach ($email as $e) { }

                $this->email->to($email);

                // var_dump($this->email->to($e->email));
                // die;


                $this->email->subject('Pembeli dataanggg, cek dulu yuk beli apa.. No. Invoice: #' . $id);
                //token pake url encode untuk mengubah encoding url yang pake % supaya karakternya gak hilang kalo keluar +




                $data = [
                    'id' => $id,
                    'email_penjual' => $email
                ];


                // var_dump($data);
                // die;
                $content2 = $this->load->view('homepage/email_content2', $data, TRUE);

                $this->email->message($content2 . 'Klik link ini untuk mengisi form resi <blank>' . '<a href="' . base_url() . 'homepage/resi?id=' . $q->id_invoice . '&id_komponen=' . $q->id_komponen . '"><button style="color: white; padding: 15px; background-color: #02925d; border-style: none; border-radius: 10px;">Klik disini untuk ketik resi</button></a>');
            }
        }

        //untuk kirimnya harus pake if
        if ($this->email->send()) {
            return true;
            $this->session->unset_userdata('id_invoice');
        } else {
            echo $this->email->print_debugger();
            die;
        }
    }

    public function resi()
    {
        $id = $this->input->get('id');
        $resi = $this->input->get('resi');
        $id_komponen = $this->input->get('id_komponen');

        // var_dump($id_komponen);
        // die;

        if (is_null($resi)) {
            $data = [
                'id' => $id,
                'id_komponen' => $id_komponen
            ];
            $this->load->view('homepage/resi', $data);
        } else {
            $query = "UPDATE `pesanan` SET `resi` = $resi WHERE `id_invoice` = $id AND `id_komponen` = $id_komponen";
            // var_dump($resi, $id, $id_komponen);
            // die;
            $this->db->query($query);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Kamu berhasil menambahkan resi.</div>');

            // $data = [
            //     'id_komponen' => $id_komponen
            // ];
            redirect('user');
        }
    }




    public function detail($id_komponen)
    {
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['user_role'] = $this->db->get_where('user_role', ['id' => $this->session->userdata('id')])->row_array();

        $data['title'] = 'Pembayaran';
        $data['komponen'] = $this->jenis_komponen->tampil_data()->result();

        //panggil data komponennya dulu
        $data['komponen'] = $this->jenis_komponen->detail_komponen($id_komponen);
        $this->load->view('templates/header', $data);
        $this->load->view('templates/homepage_sidebar', $data);
        $this->load->view('templates/homepage_topbar', $data);
        $this->load->view('homepage/detail_komponen', $data);
        $this->load->view('templates/footer', $data);
    }


    public function action()
    {
        $data['komponen'] = $this->jenis_komponen->tampil_data()->result();

        if (isset($_POST['query'])) {
            $inpText = $this->input->post('query');
            $query = "SELECT `nama_komponen` FROM `komponen` WHERE `nama_komponen` LIKE `'%$inpText%'`";
            $result = $this->db->query($query);
            if ($result->num_rows() > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<a href='#' class='list-group-item list-group-item-action border-1'>" . $row['nama_komponen'] . "</a>";
                }
            } else {
                echo "<p class='list-group-item border-1'>No Record</p>";
            }
        }

        // $query = $this->input->get('query');
        // $this->db->like('nama_komponen', $query);


        // $data = $this->db->get('komponen')->result();


        // echo json_encode($data);
    }

    // fitur search dari fikri
    function get_autocomplete()
    {
        if (isset($_GET['term'])) {
            $result = $this->blog_model->search_blog($_GET['term']);
            if (count($result) > 0) {
                foreach ($result as $row)
                    $arr_result[] = array(
                        'label'    => $row->blog_title,
                    );
                echo json_encode($arr_result);
            }
        }
    }

    function search()
    {

        $this->load->helper('text');

        //judul atas
        $data['title'] = 'TEKO - Tempat Jual-Beli Segala Komponen Digital Elektronik dan IoT';
        // $data['komponen'] = $this->jenis_komponen->tampil_data()->result();
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['user_role'] = $this->db->get_where('user_role', ['id' => $this->session->userdata('id')])->row_array();
        $title = $this->input->get('title');
        $data['komponen'] = $this->blog_model->search_blog($title);

        // var_dump($data['data']);die;


        $this->load->view('templates/header', $data);
        $this->load->view('templates/homepage_sidebar', $data);
        $this->load->view('templates/homepage_topbar', $data);
        $this->load->view('homepage/search_view', $data);
        $this->load->view('templates/footer', $data);
    }


    public function logout()
    {
        $this->session->unset_userdata('email');
        $this->session->unset_userdata('role_id');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Kamu berhasil logout!</div>');

        redirect('homepage');
    }
}
