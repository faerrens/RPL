<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
    }

    public function index() //ini untuk login.php
    {
        if ($this->session->userdata('email')) {
            redirect('user');
        } else {
            // buat rules validation dulu
            $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'required|trim|min_length[8]');

            if ($this->form_validation->run() == false) {
                $data['title'] = 'TEKO Login Form';
                $this->load->view('templates/auth_header', $data);
                $this->load->view('auth/login');
                $this->load->view('templates/auth_footer');
            } else {
                //jika validasi sukses, masuk ke fungsi private untuk login
                $this->_login();
            }
        }
    }

    private function _login()
    {
        //pertama, user bakalan masukin email dan passwordnya, kirim lewat post masukkan ke variable
        $email = $this->input->post('email', true);
        $password = $this->input->post('password');


        //kedua ngambil database usernya
        $user = $this->db->get_where('user', ['email' => $email])->row_array();
        // $user_role = $this->db->get_where('user_role', ['id' => $this->session->userdata('id')])->row_array();
        // $user_role['id'] = $user['role_id'];
        //kalo user ada
        if ($user) {
            //jika usernya ada dan aktif
            if ($user['is_active'] == 1) {
                // cek passwordnya
                if (password_verify($password, $user['password'])) { //aktifkan ini jika password menggunakan hash
                    //if ($password == $user['password']) { // aktifkan ini jika password yang digunakan tanpa hash
                    //kalo passwordnya benar, siapin data email dan role id (admin atau member)
                    $data = [
                        'email' => $user['email'],
                        'role_id' => $user['role_id'],
                        'id' => $user['id'],
                        'date_created' => $user['date_created']
                    ];


                    // $id = $this->db->get_where('user', ['role_id' => $role_id])->row_array();

                    // $data2 = array(
                    //     'id' => $user_role['id'],
                    //     'role' => $user_role['role']

                    // );

                    // $this->db->insert('user_role', $data2);

                    //lalu simpan data tadi ke dalam session supaya bisa dipanggil ke controller lain/field lain
                    $this->session->set_userdata($data); //set variable data
                    // mengarahkan ke field yang kita mau

                    //jika rolenya admin atau 1, maka redirectnya dipilih kemana
                    if ($user['role_id'] == 1) {
                        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Login Success! Hi Admin</div>');
                        redirect('admin'); //ke halaman admin
                    } else {
                        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Login Success!</div>');
                        redirect('user', 'refresh'); //ke halaman khusus user
                    }
                } else {
                    //kalo salah passwordnya
                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Password salah!</div>');
                    redirect('auth');
                }
            } else {
                //kalo email is_activenya 0, maka tandanya belum terverifikasi
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">E-mail yang kamu masukkan belum terverifikasi!</div>');
                redirect('auth');
            }
        } else {
            //kalo nggak ada ya gagal. kasih alert aja
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">E-mail yang kamu masukkan belum terdaftar!</div>');
            redirect('auth');
        }
    }

    private function _logingoogle()
    {
        //pertama, user bakalan masukin email dan passwordnya, kirim lewat post masukkan ke variable
        $id = $this->input->post('id');
        $email = $this->input->post('email');

        $image = $this->input->post('image');



        //kedua ngambil database usernya

        // $user_role = $this->db->get_where('user_role', ['id' => $this->session->userdata('id')])->row_array();
        // $user_role['id'] = $user['role_id'];
        //kalo user ada
        if ($id) {
            //jika usernya ada dan aktif

            // cek passwordnya
            //aktifkan ini jika password menggunakan hash
            //if ($password == $user['password']) { // aktifkan ini jika password yang digunakan tanpa hash
            //kalo passwordnya benar, siapin data email dan role id (admin atau member)
            $data = [
                'id' => $id,
                'name' => htmlspecialchars($this->input->post('name', true)),
                'email' => htmlspecialchars($email),
                'image' => $image,
                //'password' => $this->input->post('password1'),
                'password' => '',   //ini untuk pake hash enkripsi
                'role_id' => 2, //defaultnya member
                'is_active' => 1, //nnti bakal ada user activation yang defaultnya 0
                'date_created' => time()
            ];



            // $id = $this->db->get_where('user', ['role_id' => $role_id])->row_array();

            // $data2 = array(
            //     'id' => $user_role['id'],
            //     'role' => $user_role['role']

            // );

            // $this->db->insert('user_role', $data2);

            //lalu simpan data tadi ke dalam session supaya bisa dipanggil ke controller lain/field lain
            $this->db->insert('user', $data);
            $this->session->set_userdata($data); //set variable data
            // mengarahkan ke field yang kita mau
            $user = $this->db->get_where('user', ['email' => $email])->row_array();

            //jika rolenya admin atau 1, maka redirectnya dipilih kemana
            if ($user['role_id'] == 1) {
                $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Login Success! Hi Admin</div>');
                redirect('admin'); //ke halaman admin
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Login Success!</div>');
                redirect('user', 'refresh'); //ke halaman khusus user
            }
        } else {
            //kalo nggak ada ya gagal. kasih alert aja
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">E-mail yang kamu masukkan belum terdaftar!</div>');
            redirect('auth');
        }
    }

    public function test()
    {
        $this->form_validation->set_rules('nama', 'Nama', 'required|trim');

        if ($this->form_validation->run() == false) {

            // $data['title'] = 'WPU User Registration';
            $this->load->view('templates/auth_header');
            $this->load->view('auth/test');
            $this->load->view('templates/auth_footer');
        } else {
            $data = array(
                'nama' => $this->input->post('nama')

                // 'date_created' => time()


            );

            $this->db->insert('hari', $data);
            redirect('auth');
        }
    }

    public function registration()
    {
        //untuk menghindari link dibuka seenaknya
        if ($this->session->userdata('email')) {
            redirect('user');
        }
        //memberikan rules/aturan tiap atribut seperti nama, email dll
        // lihat name='' di php registration

        /* Komponen rules bisa dilihat di userguide code igniter: form validation -> rule reference */
        //required artinya harus diisi
        //trim fungsinya untuk menghapus spasi di depan atau belakang dan menghindari masuk ke database.
        $this->form_validation->set_rules('name', 'Name', 'required|trim');
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[user.email]', [
            'is_unique' => 'Email sudah terdaftar'
        ]); //  is_unique cek ke database email
        $this->form_validation->set_rules('password1', 'Password', 'required|trim|min_length[8]|matches[password2]'); //minimal length 8 character dan match dengan password2
        $this->form_validation->set_rules('password2', 'Retype Password', 'required|trim|matches[password1]');

        //ini untuk mengecek kalo misal belum ada data, maka tidak akan ada yang ditambahkan
        //melakukan validasi pada form.

        //jika libbrary form validasinya gagal/false ya tampilkan aja form registrasinya lagi.
        if ($this->form_validation->run() == false) {

            $data['title'] = 'TEKO Registration Form';
            $this->load->view('templates/auth_header', $data);
            $this->load->view('auth/registration');
            $this->load->view('templates/auth_footer');
        } else {
            $email = $this->input->post('email', true);
            $data = array(
                'name' => htmlspecialchars($this->input->post('name', true)),
                'email' => htmlspecialchars($email),
                'image' => 'member-default.png',
                //'password' => $this->input->post('password1'),
                'password' => password_hash($this->input->post('password1'), PASSWORD_DEFAULT),   //ini untuk pake hash enkripsi
                'role_id' => 2, //defaultnya member
                'is_active' => 0, //nnti bakal ada user activation yang defaultnya 0
                'date_created' => time()


            );



            //menyiapkan token untuk aktivasi
            $token = base64_encode(random_bytes(32)); //ini masih berupa char-char aneh belum pure alphanumeric
            //maka dari itu diterjemahkan dulu ke alphanumeric supaya dikenali oleh mysql dengan base64

            //siapkan user tokennya untuk tabel penyimpan token

            $user_token = [
                'email' => $email,
                'token' => $token,
                'date_created' => time() //untuk mengexpiredkan token
            ];

            $this->db->insert('user', $data);
            $id_user = $this->db->insert_id();


            $data2 = array(
                'id' => $id_user,
                'name' => htmlspecialchars($this->input->post('name', true)),
                'email' => htmlspecialchars($email),
                'tgl_lahir' => '',
                'gender' => '',
                'no_telp' => '',
                'no_bank' => '',
                'nama_bank' => '',
                'alamat' => '',
                'image' => ''
            );
            $this->db->insert('detail_user', $data2);

            $this->db->insert('user_token', $user_token);

            //mengirim email untuk aktivasi hehehehehehe using google api
            //untuk melakukan activation kita mengirim email dengan link yang dilik lalu harus menciptakan token, token dikirim ke aplikasi dan dicocokkna ke dalam database.


            //parameter token dimasukkan ke send email atau forgot password
            $this->_sendEmail($token, 'verify');

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Selamat, kamu sudah terdaftar! Silahkan Aktivasi Email kamu dulu untuk login!</div>');
            redirect('auth');
        }
    }

    //ambil email class dari codeigniter, type itu untuk verification atau dll
    private function _sendEmail($token, $type)
    {
        //pertama konfigurasi dulu
        $config = [
            'protocol' => 'smtp',
            'smtp_host' => 'ssl://mail.teko.my.id',
            'smtp_user' => 'no-reply@teko.my.id',
            'smtp_pass' => 'tekoadmin12345',
            'smtp_port' => 465,
            'mailtype' => 'html',
            'charset' => 'utf-8',
            'newline' => "\r\n" //kalo ngggak pake ini nggak bakal bisa kekirim karena ini sama aja kaya trigger ketika kita mencepet tombol enter
        ];

        $this->load->library('encrypt');
        //panggil librari email di CO
        //config tadi masuk ke librariy parameter
        $this->load->library('email', $config);

        //harus initialize dulu
        $this->email->initialize($config);

        //dari siapa?
        $this->email->from('no-reply@teko.my.id', 'Tempat Komponen TEKO');
        //mau dikirim kemana?
        $this->email->to($this->input->post('email'));

        //cek type
        if ($type == 'verify') {
            $this->email->subject('[Aktifkan Akunmu] TEKO');
            //token pake url encode untuk mengubah encoding url yang pake % supaya karakternya gak hilang kalo keluar +
            $this->email->message('Klik link ini untuk memverifikasi akun kamu : <a href="' . base_url() . 'auth/verify?email=' . $this->input->post('email') . '&token=' . urlencode($token) . '"><button style="color: white; padding: 20px; background-color: #02925d; border-style: none; border-radius: 10px;">Yuk Aktivasi!</button></a>');
        } else if ($type == 'forgot') {
            $this->email->subject('[Reset Passwordmu] TEKO');
            //token pake url encode untuk mengubah encoding url yang pake % supaya karakternya gak hilang kalo keluar +
            $this->email->message('Klik link ini untuk reset password akun kamu : <a href="' . base_url() . 'auth/resetpassword?email=' . $this->input->post('email') . '&token=' . urlencode($token) . '"><button style="color: white; padding: 20px; background-color: #02925d; border-style: none; border-radius: 10px;">Yuk Reset!</button></a>');
        }


        //untuk kirimnya harus pake if
        if ($this->email->send()) {
            return true;
        } else {
            echo $this->email->print_debugger();
            die;
        }
    }

    public function verify()
    {
        //fungsi untuk memverifikasi untuk link yang dikirm ke email

        //mengubah is_active kalo email dan token bener


        //ambil emailnya sama tokennya dulu dari gmail url
        $email = $this->input->get('email');
        $token = $this->input->get('token');

        //pastikan emailnya valid
        $user = $this->db->get_where('user', ['email' => $email])->row_array();

        //kalo ada usernya
        if ($user) {
            //kalo ada user email di database, query di tabel user token, ada nggak tokennya
            $user_token = $this->db->get_where('user_token', ['token' => $token])->row_array();

            if ($user_token) {

                //untuk waktu validasi
                if (time() - $user_token['date_created'] < (60 * 60 * 24)) { //jika waktu daftar kurang dari 1 hari maka boleh
                    //kalo berhasil maka ubah isactivenya

                    $this->db->set('is_active', 1);
                    $this->db->where('email', $email);
                    $this->db->update('user');

                    //jangan lupa delete user tokennya kan udah gadibutuhin
                    $this->db->delete('user_token', ['email' => $email]);

                    $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Selamat, Email ' . $email . ' sudah teraktivasi ! Silahkan login.</div>');
                    redirect('auth', 'refresh');
                } else {

                    //hapus usernya dan tokennya, jadinya dia harus daftar ulang selama 24 jam tadi expired
                    $this->db->delete('user', ['email' => $email]);
                    $this->db->delete('user_token', ['email' => $email]);

                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Token Expired!</div>');
                    redirect('auth');
                }
            } else {
                //kalo tokennya salah

                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Token Invalid</div>');
                redirect('auth');
            }
        } else {
            //kalo ngga didatabase user ada kasih pesan error aja pke flashdata
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Verifikasi akun kamu gagal! Emailnya tidak terdaftar!</div>');
            redirect('auth');
        }
    }

    public function resetpassword()
    {
        $email = $this->input->get('email');
        $token = $this->input->get('token');

        $user = $this->db->get_where('user', ['email' => $email])->row_array();

        if ($user) { //kalo usernya true, maka
            $user_token = $this->db->get_where('user_token', ['token' => $token])->row_array(); //nyari token
            if ($user_token) { //kalo token didatabase ada sesuai usernya

                //bikin session supaya data cuma server yang tau, lalu diseimpen ke reset_email
                $this->session->set_userdata('reset_email', $email);
                //redirect ke halaman change password
                $this->changepassword();
            } else {

                //ini buat display edit token lewat link, redirect ke auth
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Reset Password gagal! Token salah!</div>');
                redirect('auth');
            }
        } else {
            //ini buat display email yang diedit, redirect aja langsung
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Reset Password gagal! Email salah!</div>');
            redirect('auth');
        }
    }

    public function changepassword()
    {

        //ini untuk jaga2 kalo gaada session yang di assign redirect aja, hehe
        if (!$this->session->userdata('reset_email')) {
            redirect('auth');
        }

        //ini untuk form validationnya, buat password 1 dan password 2
        $this->form_validation->set_rules('password1', 'Password', 'trim|required|min_length[8]|matches[password2]');
        $this->form_validation->set_rules('password2', 'Retype Password', 'trim|required|matches[password1]');

        //kalo salah ya balik lagi ke halaman change password dengan viewnya
        if ($this->form_validation->run() == false) {
            $data['title'] = 'Change Password';
            $this->load->view('templates/auth_header', $data);
            $this->load->view('auth/change-password', $data);
            $this->load->view('templates/auth_footer');
        } else {
            //kalo bener

            //sebelum diupdate, password dienkripsi dulu, di hash
            $password = password_hash($this->input->post('password1'), PASSWORD_DEFAULT);
            $email = $this->session->userdata('reset_email');

            //update password
            $this->db->set('password', $password);
            $this->db->where('email', $email);
            $this->db->update('user');

            //hapus sessionnya yang udah kita buat tadi yang berisi email
            $this->session->unset_userdata('reset_email');
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Password berhasil diperbarui! silakan login!</div>');
            redirect('auth');
        }
    }

    public function forgotpassword()
    {

        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        if ($this->form_validation->run() == false) {

            $data['title'] = 'Forgot Password';
            $this->load->view('templates/auth_header', $data);
            $this->load->view('auth/forgot-password', $data);
            $this->load->view('templates/auth_footer');
        } else {
            $email = $this->input->post('email');
            $user = $this->db->get_where('user', ['email' => $email, 'is_active' => 1])->row_array();

            if ($user) {
                $token = base64_encode(random_bytes(32));
                $user_token = [
                    'email' => $email,
                    'token' => $token,
                    'date_created' => time()
                ];

                $this->db->insert('user_token', $user_token);
                $this->_sendEmail($token, 'forgot');
                $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Check email kamu untuk reset password!</div>');
                redirect('auth');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Email belum teregistrasi atau teraktivasi!</div>');
                redirect('auth/forgotpassword');
            }
        }
    }

    public function logout()
    {
        $this->session->unset_userdata('email');
        $this->session->unset_userdata('role_id');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Kamu berhasil logout!</div>');
        redirect('auth');
    }

    public function blocked()
    {
        $data['title'] = 'Access Denied';
        $this->load->view('templates/header', $data);
        $this->load->view('auth/404');
        $this->load->view('templates/footer');
    }

    public function blocked2()
    {
        $data['title'] = 'Access Denied';
        $this->load->view('templates/header', $data);
        $this->load->view('auth/4044');
        $this->load->view('templates/footer');
    }
}
