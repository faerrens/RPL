<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kategori extends CI_Controller
{
    public function dashboard()
    {
        $data['title'] = 'Dashboard';
        $data['komponen'] = $this->jenis_komponen->tampil_data()->result();
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['user_role'] = $this->db->get_where('user_role', ['id' => $this->session->userdata('id')])->row_array();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/homepage_sidebar', $data);
        $this->load->view('templates/homepage_topbar', $data);
        $this->load->view('homepage/index', $data);
        $this->load->view('templates/homepage_footer', $data);
    }
    public function komponen_pasif()
    {
        $this->load->helper('text');
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['user_role'] = $this->db->get_where('user_role', ['id' => $this->session->userdata('id')])->row_array();

        $data['title'] = 'Komponen Pasif';
        $data['komponen'] = $this->jenis_komponen->tampil_data()->result();
        $data['komponen_pasif'] = $this->model_kategori->data_komponen_pasif()->result();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/homepage_sidebar', $data);
        $this->load->view('templates/homepage_topbar', $data);
        $this->load->view('homepage/komponen_pasif', $data);
        $this->load->view('templates/footer');
    }
    public function komponen_aktif()
    {
        $this->load->helper('text');
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['user_role'] = $this->db->get_where('user_role', ['id' => $this->session->userdata('id')])->row_array();

        $data['title'] = 'Komponen Aktif';
        $data['komponen'] = $this->jenis_komponen->tampil_data()->result();
        $data['komponen_aktif'] = $this->model_kategori->data_komponen_aktif()->result();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/homepage_sidebar', $data);
        $this->load->view('templates/homepage_topbar', $data);
        $this->load->view('homepage/komponen_aktif', $data);
        $this->load->view('templates/footer');
    }

    public function project_market()
    {
        $this->load->helper('text');
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['user_role'] = $this->db->get_where('user_role', ['id' => $this->session->userdata('id')])->row_array();

        $data['title'] = 'Project IoT (Market)';
        $data['komponen'] = $this->jenis_komponen->tampil_data()->result();
        $data['project_market'] = $this->model_kategori->data_project_market()->result();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/homepage_sidebar', $data);
        $this->load->view('templates/homepage_topbar', $data);
        $this->load->view('homepage/project_market', $data);
        $this->load->view('templates/footer');
    }
    public function project_auction()
    {
        $this->load->helper('text');
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['user_role'] = $this->db->get_where('user_role', ['id' => $this->session->userdata('id')])->row_array();

        $data['title'] = 'Project IoT (Auction)';
        $data['komponen'] = $this->jenis_komponen->tampil_data()->result();
        $data['project_auction'] = $this->model_kategori->data_project_auction()->result();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/homepage_sidebar', $data);
        $this->load->view('templates/homepage_topbar', $data);
        $this->load->view('homepage/project_auction', $data);
        $this->load->view('templates/footer');
    }
}
