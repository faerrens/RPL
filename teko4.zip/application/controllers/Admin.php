<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{

    public function __construct()
    {

        //ini untuk menghindari akses langsung lewat link, 

        parent::__construct();
        is_logged_in();
    }

    public function index()
    {
        $data['invoice'] = $this->model_invoice->tampil_data_2();
        $data['komponen']  = $this->jenis_komponen->tampil_data()->result();
        $data['title'] = 'Dashboard Admin';
        //mengambil data user yang mana memiliki email terdaftar di session controller sebelumnya database
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['user_role'] = $this->db->get_where('user_role', ['id' => $this->session->userdata('id')])->row_array();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/index', $data);
        $this->load->view('templates/footer');
    }
    public function tambah_aksi()
    {

        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $nama_komponen = htmlspecialchars($this->input->post('nama_komponen'));
        $manufacture = htmlspecialchars($this->input->post('manufacture'));
        $deskripsi = htmlspecialchars($this->input->post('deskripsi'));
        $kategori = htmlspecialchars($this->input->post('kategori'));
        $harga = $this->input->post('harga');
        $stok = $this->input->post('stok');
        $image = $_FILES['image']['name'];
        if ($image) {
            $config['allowed_types'] = 'gif|jpg|png'; //tipe cuma bisa gif, jpg, png
            $config['max-size'] = '8192'; //dalam KB
            $config['upload_path'] = './assets/img/item/';  //uploadnya ke folder mana?

            $this->load->library('upload', $config); //ngeload library dari CO tentang upload confignya
            if ($this->upload->do_upload('image')) { //kalo berhasil do upload dari input yang namanya image;; dan table di dataabase di update
                $image = $this->upload->data('file_name');
            } else { //kalo gagal upload ngapain.,..
                echo $this->upload->display_errors();
            }
        }
        $data = array(
            'nama_komponen' => $nama_komponen,
            'manufacture' => $manufacture,
            'deskripsi' => $deskripsi,
            'kategori' => $kategori,
            'harga' => $harga,
            'stok' => $stok,
            'image' => $image,
            'date_created' => time()
        );

        //input ke dalam table komponen melalui model komponen
        $this->db->insert('komponen', $data);
        redirect('admin');
    }
    public function edit($id)
    {
        $data['title'] = 'Dashboard Admin';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['user_role'] = $this->db->get_where('user_role', ['id' => $this->session->userdata('id')])->row_array();
        $where = array('id_komponen' => $id);
        $data['komponen'] = $this->jenis_komponen->edit_komponen($where, 'komponen')->result();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/edit_komponen', $data);
        $this->load->view('templates/footer');
    }
    public function update()
    {

        $id = $this->input->post('id_komponen');
        $nama_komponen = $this->input->post('nama_komponen');
        $manufacture = $this->input->post('manufacture');
        $deskripsi = $this->input->post('deskripsi');

        $kategori = $this->input->post('kategori');
        $harga = $this->input->post('harga');
        $stok = $this->input->post('stok');
        $image = $_FILES['image']['name'];
        if (isset($image)) {
            $config['allowed_types'] = 'gif|jpg|png'; //tipe cuma bisa gif, jpg, png
            $config['max-size'] = '8192'; //dalam KB
            $config['upload_path'] = './assets/img/item/';  //uploadnya ke folder mana?

            $this->load->library('upload', $config); //ngeload library dari CO tentang upload confignya
            if ($this->upload->do_upload('image')) { //kalo berhasil do upload dari input yang namanya image;; dan table di dataabase di update
                $image = $this->upload->data('file_name');
            } else { //kalo gagal upload ngapain.,..
                echo $this->upload->display_errors();
            }
        }


        $data = array(
            'nama_komponen' => $nama_komponen,
            'manufacture' => $manufacture,
            'deskripsi' => $deskripsi,
            'kategori' => $kategori,
            'harga' => $harga,
            'stok' => $stok,
            'image' => $image,
            'date_created' => time()
        );

        $where = array(
            'id_komponen' => $id
        );

        $this->jenis_komponen->update_data($where, $data, 'komponen');
        redirect('admin');
        // var_dump($image1);
        // die;
    }

    public function hapus($id)
    {
        $where = array('id_komponen' => $id);
        $this->jenis_komponen->hapus_data($where, 'komponen');
        redirect('admin');
    }

    public function invoice()
    {
        //untuk ambil dan nampilin data invoice dari si model
        $data['invoice'] = $this->model_invoice->tampil_data();
        $data['title'] = 'Invoice Admin';
        //mengambil data user yang mana memiliki email terdaftar di session controller sebelumnya database
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['komponen']  = $this->jenis_komponen->tampil_data()->result();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/invoice', $data);
        $this->load->view('templates/footer');
    }
    public function detail($id_invoice)
    {
        $data['invoice'] = $this->model_invoice->tampil_data();
        $data['title'] = 'Invoice';
        //mengambil data user yang mana memiliki email terdaftar di session controller sebelumnya database
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['komponen']  = $this->jenis_komponen->tampil_data()->result();

        $data['invoice'] = $this->model_invoice->ambil_id_invoice($id_invoice);
        $data['pesanan'] = $this->model_invoice->ambil_id_pesanan($id_invoice);

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/detail_invoice', $data);
        $this->load->view('templates/footer');
    }
}
