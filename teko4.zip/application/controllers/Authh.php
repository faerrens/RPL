<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Authh extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
    }


    public function index() //ini untuk login.php
    {

        // buat rules validation dulu
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'required|trim|min_length[8]');

        if ($this->form_validation->run() == false) {
            $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
            $data['user_role'] = $this->db->get_where('user_role', ['id' => $this->session->userdata('id')])->row_array();
            $data['komponen'] = $this->jenis_komponen->tampil_data()->result();
            $data['title'] = 'TEKO Login Form';
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Masukkan Data Dengan Benar</div>');
            redirect('homepage');
        } else {
            //jika validasi sukses, masuk ke fungsi private untuk login
            $this->_login();
        }
    }

    private function _login()
    {
        //pertama, user bakalan masukin email dan passwordnya, kirim lewat post masukkan ke variable
        $email = $this->input->post('email', true);
        $password = $this->input->post('password');


        //kedua ngambil database usernya
        $user = $this->db->get_where('user', ['email' => $email])->row_array();
        // $user_role = $this->db->get_where('user_role', ['id' => $this->session->userdata('id')])->row_array();
        // $user_role['id'] = $user['role_id'];
        //kalo user ada
        if ($user) {
            //jika usernya ada dan aktif
            if ($user['is_active'] == 1) {
                // cek passwordnya
                if (password_verify($password, $user['password'])) { //aktifkan ini jika password menggunakan hash
                    //if ($password == $user['password']) { // aktifkan ini jika password yang digunakan tanpa hash
                    //kalo passwordnya benar, siapin data email dan role id (admin atau member)
                    $data = [
                        'id' => $user['id'],
                        'email' => $user['email'],
                        'role_id' => $user['role_id'],
                        'date_created' => $user['date_created']
                    ];


                    // $id = $this->db->get_where('user', ['role_id' => $role_id])->row_array();

                    // $data2 = array(
                    //     'id' => $user_role['id'],
                    //     'role' => $user_role['role']

                    // );

                    // $this->db->insert('user_role', $data2);

                    //lalu simpan data tadi ke dalam session supaya bisa dipanggil ke controller lain/field lain
                    $this->session->set_userdata($data); //set variable data
                    // mengarahkan ke field yang kita mau

                    //jika rolenya admin atau 1, maka redirectnya dipilih kemana
                    if ($user['role_id'] == 1) {
                        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Login Success!</div>');
                        redirect('homepage'); //ke halaman homepage
                    } else {
                        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Login Success!</div>');
                        redirect('homepage'); //ke halaman homepage
                    }
                } else {
                    //kalo salah passwordnya
                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Password salah!</div>');
                    redirect('homepage');
                }
            } else {
                //kalo email is_activenya 0, maka tandanya belum terverifikasi
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">E-mail yang kamu masukkan belum terverifikasi!</div>');
                redirect('homepage');
            }
        } else {
            //kalo nggak ada ya gagal. kasih alert aja
            $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">E-mail yang kamu masukkan belum terdaftar!</div>');
            redirect('homepage');
        }
    }

    public function logout()
    {
        $this->session->unset_userdata('email');
        $this->session->unset_userdata('role_id');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Kamu berhasil logout!</div>');
        redirect('homepage');
    }
}
