<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{

    public function __construct()
    {

        parent::__construct();
        //untuk cek dia udah login atau belom, atau dia rolenya apa, ini ngambil helper yang dibuat sendii namanya teko_helper.php di folder helper
        is_logged_in();
        $this->load->library('upload');
        $this->load->library('image_lib');
    }

    public function index()
    {
        $data['title'] = 'Informasi';
        //mengambil data user yang mana memiliki email terdaftar di session controller sebelumnya database
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['detail_user'] = $this->db->get_where('detail_user', ['email' => $this->session->userdata('email')])->row_array();
        $data['komponen']  = $this->jenis_komponen->tampil_data()->result();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('user/index', $data);
        $this->load->view('templates/footer');
    }

    public function detail_user()
    {
        $data['title'] = 'Informasi';
        //mengambil data user yang mana memiliki email terdaftar di session controller sebelumnya database
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['detail_user'] = $this->db->get_where('detail_user', ['email' => $this->session->userdata('email')])->row_array();
        $data['komponen']  = $this->jenis_komponen->tampil_data()->result();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('user/detail_user', $data);
        $this->load->view('templates/footer');
    }

    public function update_detail_user()
    {

        $id = $this->session->userdata('id');
        $name = $this->input->post('name');
        $email = $this->session->userdata('email');
        $tgl_lahir = $this->input->post('tgl_lahir');

        $gender = $this->input->post('gender');
        $no_telp = $this->input->post('no_telp');
        $no_bank = $this->input->post('no_bank');
        $nama_bank = $this->input->post('nama_bank');
        $alamat = $this->input->post('alamat');


        $config['upload_path'] = './assets/img/profile/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg';

        $config['file_name'] = str_replace('_', '', str_replace(' ', '', strtolower($_FILES['image']['name'])));

        if ($config['file_name'] == '') {
            $querys = "SELECT * FROM `detail_user` WHERE `id` = $id";
            $file = $this->db->query($querys);
            foreach ($file->result() as $r) {
                $config['file_name'] = $r->image;
            }
        } else {
            $config['file_name'] = time() . str_replace('_', '', str_replace(' ', '', strtolower($_FILES['image']['name'])));
            $this->upload->initialize($config);
            $this->upload->do_upload('image');
        }


        $data = array(
            'id' => $id,
            'name' => $name,
            'email' => $email,
            'tgl_lahir' => $tgl_lahir,
            'gender' => $gender,
            'no_telp' => $no_telp,
            'no_bank' => $no_bank,
            'nama_bank' => $nama_bank,
            'alamat' => $alamat,
            'image' => $config['file_name']
        );

        $where = array(
            'id' => $id
        );

        $image = $config['file_name'];

        $query = "UPDATE `user` SET `image` = '$image', `name` = '$name' WHERE `id` = $id";
        $this->db->query($query);

        $this->detail_user->update_detail($where, $data, 'detail_user');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Selamat, data kamu sudah diperbarui.</div>');
        redirect('user');
        // var_dump($config['file_name']);
        // die;
    }


    public function jual()
    {
        $this->load->library('form_validation');
        $data['title'] = 'Jual Komponen/Project IoT';

        $data['komponen']  = $this->jenis_komponen->tampil_data_2()->result();
        //mengambil data user yang mana memiliki email terdaftar di session controller sebelumnya database
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('nama_komponen', 'Nama_komponen', 'required|trim|min_length[2]', [
            'min_length' => 'Isi minimal 2 karakter'
        ]);
        $this->form_validation->set_rules('manufacture', 'Manufacture', 'required|trim|min_length[2]', [
            'min_length' => 'Isi minimal 2 karakter'
        ]);
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required|trim|min_length[5]', [
            'min_length' => 'Isi minimal 10 karakter'
        ]);
        // $this->form_validation->set_rules('image', 'Image', 'required', [
        //     'required' => 'Upload gambarmu dulu ya'
        // ]);
        $this->form_validation->set_rules('harga', 'Harga', 'required|trim|integer', [
            'required' => 'Harga jangan kasih gratis',
            'integer' => 'Masukkan hanya angka'
        ]);
        $this->form_validation->set_rules('stok', 'Stok', 'required|trim|integer', [
            'required' => 'Stok jangan 0',
            'integer' => 'Masukkan hanya angka'
        ]);
        // $this->form_validation->set_rules('kategori', 'Kategori', 'required');


        if ($this->form_validation->run() == false) {

            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('user/jual', $data);
            $this->load->view('templates/footer');
        } else {

            // jika ada gambar yang akan diupload bisa ke dokumentasi dari CodeIgniter tentang File Uploading Class lalu Setting Preferences
            // $this->load->library('image_lib');
            // $upload_image = $_FILES['image']['name'];  //ketika image diupload maka akan ada string2 yang masuk makanya diliat dari vardump dulu
            // if ($upload_image) {
            //     $config['file_name'] = str_replace('_', '', str_replace(' ', '', strtolower($_FILES['image']['name'])));
            //     $config['allowed_types'] = 'gif|jpg|png|jpeg'; //tipe cuma bisa gif, jpg, png
            //     $config['max-size'] = '8192'; //dalam KB
            //     $config['upload_path'] = './assets/img/item/';  //uploadnya ke folder mana?

            //     $path = './assets/img/item/' . str_replace('_', '', str_replace(' ', '', strtolower($_FILES['image']['name'])));

            //     $this->upload->initialize($config);
            //     //ngeload library dari CO tentang upload confignya
            //     if ($this->upload->do_upload('image')) { //kalo berhasil do upload dari input yang namanya image;; dan table di dataabase di update
            //         $new_image = $this->upload->data('file_name');
            //         $config2['image_library'] = 'gd2';
            //         $config2['source_image'] = './assets/img/item/' . $this->upload->file_name;
            //         $config2['create_thumb'] = FALSE;
            //         $config2['maintain_ratio'] = FALSE;
            //         $config2['width'] = 10;
            //         $config2['height'] = 10;

            //         $this->image_lib->resize();
            //         $this->image_lib->clear();
            //     } else { //kalo gagal upload ngapain.,..
            //         echo $this->upload->display_errors();
            //     }
            // }


            $config['upload_path'] = './assets/img/item/';
            $config['allowed_types'] = 'gif|jpg|png|jpeg';

            $config['file_name'] = time() . str_replace('_', '', str_replace(' ', '', strtolower($_FILES['image']['name'])));

            $this->upload->initialize($config);
            $this->upload->do_upload('image');
            $path = './assets/img/item/' . time() . str_replace('_', '', str_replace(' ', '', strtolower($_FILES['image']['name'])));

            $upload_data = $this->upload->data();
            $upload_img_data = getimagesize($upload_data['full_path']);
            $water_mark = "";
            $configrez['image_library'] = 'gd2';
            $configrez['source_image'] = $path;
            $configrez['create_thumb'] = false;
            $configrez['maintain_ratio'] = false;

            if ($upload_img_data[0] > $upload_img_data[1]) {

                $configrez['width'] = $upload_img_data[1];
                $configrez['height'] = $upload_img_data[1];
                $configrez['x_axis'] = ($upload_img_data[0] - $upload_img_data[1]) / 2;
                $configrez['y_axis'] = 0;
                $water_mark = $upload_img_data[1];
            } else {

                $configrez['width'] = $upload_img_data[0];
                $configrez['height'] = $upload_img_data[0];
                $configrez['x_axis'] = 0;
                $configrez['y_axis'] = ($upload_img_data[1] - $upload_img_data[0]) / 2;
                $water_mark = $upload_img_data[0];
            }
            $this->image_lib->initialize($configrez);
            $this->image_lib->crop();

            $configrez2['image_library'] = 'gd2';
            $configrez2['source_image'] = $path;
            $configrez2['create_thumb'] = false;
            $configrez2['maintain_ratio'] = false;
            $configrez2['width'] = "700";
            $configrez2['height'] = "700";
            $this->image_lib->initialize($configrez2);
            $this->image_lib->resize();

            $configwm['source_image'] = $path;
            $configwm['wm_overlay_path'] = './assets/img/item/watermark.png';
            $configwm['wm_type'] = 'overlay';
            $configwm['wm_opacity'] = '100';
            $configwm['wm_vrt_alignment'] = 'middle';
            $configwm['wm_hor_alignment'] = 'center';
            $this->image_lib->initialize($configwm);
            $this->image_lib->watermark();






            $data = array(
                'nama_komponen' => htmlspecialchars($this->input->post('nama_komponen', true)),
                'manufacture' => htmlspecialchars($this->input->post('manufacture', true)),
                'deskripsi' => htmlspecialchars($this->input->post('deskripsi', true)),
                'kategori' => $this->input->post('kategori'), //--member--
                'harga' => $this->input->post('harga'),
                'stok' => $this->input->post('stok'),
                'image' => $config['file_name'],

                //ini untuk pake hash enkripsi

                'date_created' => time(),
                'id_customer' => $this->session->userdata('id')

            );

            $this->db->insert('komponen', $data);



            // $id_id = $this->session->userdata('id');

            // $q = "SELECT `id_komponen` FROM `komponen` WHERE `id_customer` = $id_id LIMIT 1";
            // $query = $this->db->query($q);
            // $res = $query->result();  // this returns an object of all results
            // foreach ($res as $r) {
            //     $r->id_komponen;
            // }


            $ambil_jual = array(
                'id_customer' => $this->session->userdata('id'),
                'id_komponen' => $this->jenis_komponen->ambil_id_komponen()
            );


            $this->db->insert('jual', $ambil_jual);



            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Selamat, item kamu sudah ditambahkan. Lihat <a href="#bottom"><button class="btn btn-md btn-info">Item yang kamu jual</button></a></div>');
            redirect('user/jual'); //ini untuk redirect ke halaman tertambahnya item si penjual

            // var_dump($configrez2['new_image']);
            // die;
        }
    }


    public function edit($id)
    {
        $data['title'] = 'Jual Komponen/Project IoT';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['user_role'] = $this->db->get_where('user_role', ['id' => $this->session->userdata('id')])->row_array();
        $where = array('id_komponen' => $id);
        $data['komponen'] = $this->jenis_komponen->edit_komponen($where, 'komponen')->result();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('user/edit_komponen', $data);
        $this->load->view('templates/footer');
    }
    public function update()
    {

        $id = $this->input->post('id_komponen');
        $nama_komponen = $this->input->post('nama_komponen');
        $manufacture = $this->input->post('manufacture');
        $deskripsi = $this->input->post('deskripsi');

        $kategori = $this->input->post('kategori');
        $harga = $this->input->post('harga');
        $stok = $this->input->post('stok');
        $image2 = $_FILES['image2']['name'];
        if ($image2) {
            $config['allowed_types'] = 'gif|jpg|png'; //tipe cuma bisa gif, jpg, png
            $config['max-size'] = '8192'; //dalam KB
            $config['upload_path'] = './assets/img/item/';  //uploadnya ke folder mana?

            $this->load->library('upload', $config); //ngeload library dari CO tentang upload confignya
            if ($this->upload->do_upload('image2')) { //kalo berhasil do upload dari input yang namanya image;; dan table di dataabase di update
                $image2 = $this->upload->data('file_name');
            } else { //kalo gagal upload ngapain.,..
                echo $this->upload->display_errors();
            }
        }


        $data = array(
            'nama_komponen' => $nama_komponen,
            'manufacture' => $manufacture,

            'deskripsi' => $deskripsi,
            'kategori' => $kategori,
            'harga' => $harga,
            'stok' => $stok,
            'image' => $image2,
            'date_created' => time()
        );

        $where = array(
            'id_komponen' => $id
        );

        $this->jenis_komponen->update_data($where, $data, 'komponen');
        // var_dump($image2);
        // die;
        redirect('user/jual');
    }

    public function hapus($id)
    {
        $where = array('id_komponen' => $id);
        $this->jenis_komponen->hapus_data($where, 'komponen');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Item berhasil dihapus</div>');
        redirect('user/jual');
    }


    public function invoice()
    {
        //untuk ambil dan nampilin data invoice dari si model

        $data['invoice'] = $this->model_invoice->tampil_data_2();
        $data['title'] = 'Invoice';
        //mengambil data user yang mana memiliki email terdaftar di session controller sebelumnya database
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['komponen']  = $this->jenis_komponen->tampil_data()->result();
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('user/invoice', $data);
        $this->load->view('templates/footer');
    }

    public function detail($id_invoice)
    {
        $data['invoice'] = $this->model_invoice->tampil_data_2();
        $data['title'] = 'Invoice';
        //mengambil data user yang mana memiliki email terdaftar di session controller sebelumnya database
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['komponen']  = $this->jenis_komponen->tampil_data()->result();

        $data['invoice'] = $this->model_invoice->ambil_id_invoice($id_invoice);
        $data['pesanan'] = $this->model_invoice->ambil_id_pesanan($id_invoice);

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('user/detail_invoice', $data);
        $this->load->view('templates/footer');
    }

    public function fileupload()
    {


        // File upload


        if (!empty($_FILES['file']['name'])) {

            // Set preference
            $config['upload_path'] = 'uploads/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['max_size'] = '1024'; // max_size in kb
            $config['file_name'] = $_FILES['file']['name'];

            //Load upload library
            $this->load->library('upload', $config);

            // File upload
            if ($this->upload->do_upload('file')) {
                // Get data about the file
                $uploadData = $this->upload->data();
            }
        }
    }


    public function changepassword()
    {
        $data['title'] = 'Change Password';
        //mengambil data user yang mana memiliki email terdaftar di session controller sebelumnya database
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();
        $data['komponen']  = $this->jenis_komponen->tampil_data()->result();

        //form validation untuk change password

        $this->form_validation->set_rules('current_password', 'Current Password', 'required|trim');
        $this->form_validation->set_rules('new_password1', 'New Password', 'required|trim|min_length[8]|matches[new_password2]'); //minimal length 8 character dan match dengan password2
        $this->form_validation->set_rules('new_password2', 'Repeat Password', 'required|trim|matches[new_password1]');


        if ($this->form_validation->run() == false) {

            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('user/changepassword', $data);
            $this->load->view('templates/footer');
        } else {
            $new_password = $this->input->post('new_password1');
            //ngambil input dari current password secara post
            $current_password = $this->input->post('current_password');
            if (!password_verify($current_password, $data['user']['password'])) {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Current Password Salah.</div>');
                // var_dump(password_verify($current_password, $data['user']['password']));
                // die;
                redirect('user/changepassword');
            } else {
                if ($current_password == $new_password) {
                    $this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">Password baru tidak boleh sama dengan password lama.</div>');
                    redirect('user/changepassword');
                } else {

                    $password_hash = password_hash($new_password, PASSWORD_DEFAULT);
                    $this->db->set('password', $password_hash);
                    $this->db->where('email', $this->session->userdata('email'));
                    $this->db->update('user');
                    $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Password berhasil diperbarui</div>');
                    redirect('user/changepassword');
                }
            }
        }
    }
}
