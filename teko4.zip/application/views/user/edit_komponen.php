<div class="container-fluid">
    <h3><i class="fas fa-edit"></i> EDIT DATA KOMPONEN</h3>
    <?php foreach ($komponen as $kom) : ?>
        <?= form_open_multipart('user/update'); ?>
        <div class="form-group">
            <label for="">Nama Komponen</label>
            <input type="text" name="nama_komponen" class="form-control" value="<?= $kom->nama_komponen ?>">
            <input type="hidden" name="id_komponen" class="form-control" value="<?= $kom->id_komponen ?>">
        </div>
        <div class="form-group">
            <label for="manufacture">Manufaktur</label>
            <input type="text" name="manufacture" class="form-control" value="<?= $kom->manufacture ?>">
        </div>

        <div class="form-group">
            <label for="deskripsi">Deskripsi</label>
            <input type="text" name="deskripsi" class="form-control" value="<?= $kom->deskripsi ?>">
        </div>
        <div class="form-group">
            <label for="kategori">Kategori</label>

            <select class="form-control" placeholder="Pilih..." id="kategori" name="kategori" <?= set_value('kategori'); ?>>
                <option value="Komponen Pasif">Komponen Pasif</option>
                <option value="Komponen Aktif">Komponen Aktif</option>
                <option value="Project IoT (Market)">Jual Project IoT</option>
                <option value="Project IoT (Auction)">Lelang Project IoT</option>
                <option value="Project IoT (Rent)">Sewakan Project IoT</option>
                <?= form_error('kategori', '<small class="alert alert-danger px-0 py-0">', '</small>'); ?>
            </select>

        </div>
        <div class="form-group">
            <label for="harga">Harga</label>
            <input type="text" name="harga" class="form-control" value="<?= $kom->harga ?>">
        </div>
        <div class="form-group">
            <label for="stok">Jumlah Stok</label>
            <input type="text" name="stok" class="form-control" value="<?= $kom->stok ?>">
        </div>
        <div class="form-group">
            <label for="image2">Gambar</label>
            <div class="custom-file">
                <input type="file" class="custom-file-input" id="image2" name="image2" />
                <label class="custom-file-label" for="image2">Pilih gambar</label>
            </div>
        </div>
        <div class="form-group">
            <label for="date_created">Date</label>
            <input type="text" name="date_created" class="form-control" value="<?= $kom->date_created ?>">
        </div>

        <div class="row">
            <button type="submit" class="btn btn-success btn-sm ml-3">Simpan</button>
            <a href="<?= base_url('user/jual'); ?>"><button type="button" class="btn btn-danger btn-sm ml-2">Kembali</button></a>
        </div>

    <?php endforeach; ?>
</div>