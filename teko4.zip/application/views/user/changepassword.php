<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <!-- Card dari bootstrap -->
    <?= $this->session->flashdata('message'); ?>
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
    <div class="card mb-3" style="max-width: 540px;">
        <div class="row no-gutters">
            <div class="col-md-4">
                <img src="<?= base_url('assets/img/profile/') . $user['image']; ?>" class="card-img">
            </div>
            <div class="col-md-8">
                <div class="card-body">
                    <h5 class="card-title"><?= $user['name']; ?></h5>
                    <p class="card-text"><?= $user['email']; ?></p>
                    <p class="card-text"><small class="text-muted"><?php if ($user['role_id'] == 1) {
                                                                        echo "Administrator";
                                                                    } else {
                                                                        echo "Member";
                                                                    } ?> Since <?php echo date("l, d-M-Y", $user['date_created']); ?></small></p>
                </div>
            </div>
        </div>
    </div>






    <div class="row">
        <div class="col-lg-6 mx-auto">
            <?= $this->session->flashdata('message'); ?>
            <form action="<?= base_url('user/changepassword'); ?>" method="post">
                <div class="form-group">
                    <label for="current_password">Current Password</label>
                    <input type="password" name="current_password" id="current_password" class="form-control">
                    <?= form_error('current_password', '<small class="text-danger alert-warning">', '</small>'); ?>
                </div>
                <div class="form-group">
                    <label for="new_password1">New Password</label>
                    <input type="password" name="new_password1" id="new_password1" class="form-control">
                    <?= form_error('new_password1', '<small class="text-danger alert-warning">', '</small>'); ?>
                </div>
                <div class="form-group">
                    <label for="new_password2">Repeat Password</label>
                    <input type="password" name="new_password2" id="new_password2" class="form-control">
                    <?= form_error('new_password2', '<small class="text-danger alert-warning">', '</small>'); ?>
                </div>
                <div class="form-group" align="center">

                    <button type="submit" class="btn btn-sm btn-success">Change Password</button>
                </div>
            </form>
        </div>
    </div>


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->