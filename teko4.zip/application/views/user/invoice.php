<div class="container-fluid">

    <h4>Invoice Pemesanan Komponen</h4>

    <?php
    $check = $this->model_invoice->tampil_data_2();
    if ($check !== FALSE) { ?>
        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-success">Invoice</h6>
            </div>





            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">

                        <thead>
                            <tr>
                                <th>No Invoice</th>
                                <th>Nama Pemesan</th>
                                <th>Komponen</th>
                                <th>Alamat Pengiriman</th>
                                <th>Kurir</th>
                                <th>Tanggal Pemesanan</th>
                                <th>Batas Pembayaran</th>
                                <th>Status Bayar</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php




                                foreach ($invoice as $inv) : ?>

                                <tr>

                                    <td><?= $inv->id_invoice; ?></td>
                                    <td><?= $inv->nama; ?></td>
                                    <td><?php
                                                echo ($inv->nama_komponen);
                                                ?></td>
                                    <td><?= $inv->alamat; ?></td>
                                    <td><?= $inv->kurir;
                                                $resi = $inv->id_invoice;
                                                if ($inv->resi == 0) { ?><br>
                                            <small class="small">Waiting for Resi</small>
                                        <?php  } else {
                                                    ?>
                                            <button type="button" class="btn btn-warning" data-toggle="modal" data-target="#resi<?= $inv->id_invoice . $inv->id_komponen ?>">
                                                Cek Resi
                                            </button>



                                            <!-- Modal -->
                                            <div class="modal fade" id="resi<?= $inv->id_invoice . $inv->id_komponen ?>" tabindex="-1" role="dialog" aria-labelledby="resi<?= $inv->id_invoice . $inv->id_komponen ?>Title" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="resi<?= $inv->id_invoice . $inv->id_komponen ?>Title">resi invoice: #<?= $inv->id_invoice ?> <?= $inv->kurir; ?></h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body text-center">
                                                            <div class="row">
                                                                <div class="col-sm-9">

                                                                    <input type="text" class="form-control" id="clipboardExample1<?= $inv->id_invoice . $inv->id_komponen ?>" readonly value="<?= $inv->resi; ?>" />

                                                                </div>
                                                                <div class="col-sm-3">
                                                                    <button class=" btn btn-sm btn-primary btn-clipboard" data-clipboard-action="copy" data-clipboard-target="#clipboardExample1<?= $inv->id_invoice . $inv->id_komponen ?>"><i class="fas fa-copy"></i> COPY</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">ESC/Close</button>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php
                                                } ?>
                                    </td>
                                    <td><?= $inv->tgl_pesan; ?></td>
                                    <td><?= $inv->batas_bayar; ?></td>
                                    <td><?php if ($inv->status_bayar == 0) {
                                                    echo "Belum Dibayar";
                                                } else if ($inv->status_bayar == 1) {
                                                    echo "Sudah Dibayar";
                                                } ?></td>

                                    <!-- panggil controller invoice untuk detail -->
                                    <td><?= anchor('user/detail/' . $inv->id_invoice, '<div class="btn btn-sm btn-warning">Detail</div>');  ?>

                                    </td>

                                </tr>

                            <?php
                                endforeach;
                                ?>

                        </tbody>
                    </table>
                </div>
            </div>


        </div>

    <?php
    } else {
        ?>

        <div class="row">
            <div class="col-sm-12">
                <div class="alert alert-info" role="alert">

                    <h4 class="alert-heading">HAI...</h4>
                    <hr>
                    <p>Kamu masih belum memiliki pesanan apapun, silahkan klik <a class="badge badge-danger" href="<?= base_url('homepage'); ?>">disini</a> untuk membeli yang kamu butuhkan :)</p>
                </div>
            </div>
        </div>

    <?php }
    ?>



</div>



</div>

<!-- Button trigger modal -->