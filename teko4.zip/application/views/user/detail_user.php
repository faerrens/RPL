<!-- Begin Page Content -->
<div class="container-fluid">

    <div class="row">
        <div class="col">

            <!-- Page Heading -->
            <!-- Card dari bootstrap -->
            <?= $this->session->flashdata('message'); ?>
            <h1 class="h3 mb-4 text-gray-800">Detail Profil</h1>


            <form action="<?= base_url('user/update_detail_user') ?>" method="post" enctype="multipart/form-data">
                <div class="form-group row">
                    <label for="email" class="col-sm-2 col-form-label">Email</label>
                    <div class="col-sm-10">
                        <input type="text" readonly class="form-control" name="email" id="email" value="<?= $user['email']; ?>">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="name" class="col-sm-2 col-form-label">Nama Lengkap</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="name" id="name" value="<?= $detail_user['name']; ?>">

                    </div>
                </div>


                <div class="form-group row">
                    <label for="alamat" class="col-sm-2 col-form-label">Alamat Lengkap</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="alamat" id="alamat" value="<?= $detail_user['alamat']; ?>">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="tgl_lahir" class="col-sm-2 col-form-label">Tanggal Lahir</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" autocomplete="off" name="tgl_lahir" id="picker" value="<?= $detail_user['tgl_lahir']; ?>" placeholder="Klik Tanggal Lahirmu">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="gender" class="col-sm-2 col-form-label">Jenis Kelamin</label>
                    <div class="col-sm-10">
                        <select class="form-control" name="gender" id="gender">
                            <option value="pria">Laki-laki</option>
                            <option value="wanita">Perempuan</option>
                        </select>
                    </div>
                </div>
                <div class=" form-group row">
                    <label for="no_telp" class="col-sm-2 col-form-label">Nomor Telepon</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="no_telp" id="no_telp" value="<?= $detail_user['no_telp']; ?>">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="nama_bank" class="col-sm-2 col-form-label">Bank</label>
                    <div class="col-sm-10">
                        <select class="form-control" name="nama_bank" id="nama_bank">
                            <option value="mandiri">BANK MANDIRI</option>
                            <option value="bca">BANK BCA</option>
                            <option value="BRI">BANK BRI</option>
                            <option value="BNI">BANK BNI</option>
                            <option value="BTN">BANK BTN</option>
                            <option value="CIMB">CIMB</option>
                            <option value="PERMATA">BANK PERMATA</option>
                            <option value="PANIN">PANIN BANK</option>
                        </select>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="no_bank" class="col-sm-2 col-form-label">Nomor Rekening</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="no_bank" id="no_bank" value="<?= $detail_user['no_bank']; ?>">
                    </div>
                </div>

                <div class="form-group row">
                    <label for="image" class="col-sm-2 col-form-label">Gambar Profil</label>
                    <div class="col-sm-10">
                        <input type="file" name="image" class="form-control-file" id="image" />
                    </div>
                </div>

                <div class="form-group row text-center">
                    <div class="col-sm-12">
                        <button type="submit" class="btn btn-lg btn-success">Perbarui</button>
                    </div>
                </div>
            </form>

        </div>
    </div>


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->