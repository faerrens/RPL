<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <!-- Card dari bootstrap -->
    <h1 class="h3 mb-4 text-gray-800">Jual Komponen dan Project IoT kamu Yuk~</h1>
    <?= $this->session->flashdata('message'); ?>

    <div class="row">
        <div class="col-lg-10 mx-auto">

            <!-- FORM DARI BOOTSTRAP -->
            <?= form_open_multipart('user/jual'); ?>
            <div class="form-group row">
                <label for="nama_komponen" class="col-sm-2 col-form-label">Nama/Judul</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="nama_komponen" id="nama_komponen" placeholder="Isi nama Komponen / Project IoT mu" autocomplete="off" value="<?= set_value('nama_komponen'); ?>">
                    <?= form_error('nama_komponen', '<small class="alert alert-danger px-0 py-0">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="manufacture" class="col-sm-2 col-form-label">Dirakit oleh</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="manufacture" id="manufacture" placeholder="Nama manufaktur perakit" autocomplete="off" value="<?= set_value('manufacture'); ?>">
                    <?= form_error('manufacture', '<small class="alert alert-danger px-0 py-0">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="deskripsi" class="col-sm-2 col-form-label">Deskripsi Lengkap</label>
                <div class="col-sm-8">
                    <textarea class="form-control" name="deskripsi" id="deskripsi" rows="3"></textarea>
                    <?= form_error('deskripsi', '<small class="alert alert-danger px-0 py-0">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-2 col-form-label">Kategori</div>
                <div class="input-group col-sm-8">
                    <select class="custom-select rounded" placeholder="Pilih..." id="kategori" name="kategori" <?= set_value('kategori'); ?>>
                        <option value="Komponen Pasif">Komponen Pasif</option>
                        <option value="Komponen Aktif">Komponen Aktif</option>
                        <option value="Project IoT (Market)">Jual Project IoT</option>
                        <option value="Project IoT (Auction)">Lelang Project IoT</option>
                        <option value="Project IoT (Rent)">Sewakan Project IoT</option>
                        <?= form_error('kategori', '<small class="alert alert-danger px-0 py-0">', '</small>'); ?>
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <label for="harga" class="col-sm-2 col-form-label">Harga</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="harga" id="harga" placeholder="Ketik harga (e.g., 50000)" autocomplete="off" value="<?= set_value('harga'); ?>">
                    <?= form_error('harga', '<small class="alert alert-danger px-0 py-0">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="stok" class="col-sm-2 col-form-label">Stok</label>
                <div class="col-sm-8">
                    <input type="text" class="form-control" name="stok" id="stok" placeholder="Ketik stok (e.g., 50)" autocomplete="off" value="<?= set_value('stok'); ?>">
                    <?= form_error('stok', '<small class="alert alert-danger px-0 py-0">', '</small>'); ?>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-2">Gambar</div>
                <div class="col-sm-8">
                    <div class="row">
                        <div class="col-sm-3">
                            <img src="<?= base_url('assets/img/profile/') . $user['image']; ?>" class="img-thumbnail" alt="">
                        </div>
                        <div class="col-sm-9">
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="image" name="image">
                                <label class="custom-file-label" for="image">Pilih gambar</label>
                            </div>
                            <?= form_error('image', '<small class="alert alert-danger px-0 py-0">', '</small>'); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="form-group row">
        <div class="col-sm-12" align="center"><button type="button" class="btn btn-success" data-toggle="modal" data-target="#submitmodal">Pamerin dulu aja!</button></div>
    </div>


    <!-- nyoba tampilin apa yang dia jual -->



    <?php $hasil = $this->jenis_komponen->tampil_data_2();
    if ($hasil->num_rows() > 0) { ?>
        <div class="table-responsive">
            <table class="table">
                <tr align="center">
                    <th colspan="12">Berikut komponen yang telah kamu pamerkan, silahkan <span class="text-info">edit</span> atau <span class="text-danger">hapus</span></th>
                </tr>
                <tr>
                    <th>No</th>
                    <th>Nama Komponen</th>
                    <th>Manufacture</th>

                    <th>Deskripsi</th>
                    <th>Kategori</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <!-- <th>Jenis Lapak</th> -->
                    <th>Image</th>
                    <th>Date</th>
                    <th colspan="3">AKSI</th>
                </tr>
                <?php
                    $no = 1;
                    //$query = $this->db->query('SELECT * FROM `komponen k`, `user u` WHERE ') 
                    foreach ($komponen as $kom) : ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td><?= $kom->nama_komponen; ?></td>
                        <td><?= $kom->manufacture; ?></td>

                        <!-- <td></td>
                <td></td> -->
                        <td><?= $kom->deskripsi; ?></td>
                        <td><?= $kom->kategori; ?></td>
                        <td><?= $kom->harga; ?></td>
                        <td><?= $kom->stok; ?></td>
                        <!-- <td></td> -->
                        <td><?= $kom->image; ?></td>
                        <td><?= $kom->date_created; ?></td>
                        <td>
                            <div class="btn btn-success" btn-sm><i class="fas fa-search-plus"></i></div>
                        </td>
                        <td>
                            <?php echo anchor('user/edit/' . $kom->id_komponen, '<div class="btn btn-info" btn-sm><i class="fas fa-edit"></i></div>'); ?>
                        </td>
                        <td>
                            <?php echo anchor('user/hapus/' . $kom->id_komponen, '<div class="btn btn-danger" btn-sm><i class="fas fa-trash"></i></div>'); ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    <?php } else { ?>
        <div class="mt-5 text-center alert alert-secondary">Kamu belum pernah menambahkan komponenmu? Ayo.. Pamerkan komponenmu, dan dapatkan keuntungannya!</div>
    <?php } ?>



</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- Button trigger modal -->

<!-- Modal -->
<div class=" modal fade" id="submitmodal" tabindex="-1" role="dialog" aria-labelledby="submitmodalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="submitmodalTitle">Warning!</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Klik 'Siap' untuk mendaftarkan item kamu di marketplace
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tidak</button>
                <button type="submit" class="btn btn-success">Siap!</button>
            </div>
        </div>
    </div>
</div>


<!-- tambahan form untuk yang ingin melelang -->