<!-- Begin Page Content -->
<div class="container-fluid">

    <div class="row">
        <div class="col">

            <!-- Page Heading -->
            <!-- Card dari bootstrap -->
            <?= $this->session->flashdata('message'); ?>
            <h1 class="h3 mb-4 text-gray-800">Profil Saya</h1>

            <div class="card shadow mb-3" style="max-width: 540px;">
                <div class="row no-gutters">
                    <div class="col-md-4">
                        <img src="<?= base_url('assets/img/profile/') . $user['image']; ?>" class="card-img">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title"><?= $user['name']; ?></h5>
                            <p class="card-text"><?= $user['email']; ?></p>
                            <p class="card-text"><small class="text-muted"><?php if ($user['role_id'] == 1) {
                                                                                echo "Administrator";
                                                                            } else {
                                                                                echo "Member";
                                                                            } ?> Since <?php echo date("l, d-M-Y", $user['date_created']); ?></small></p>
                        </div>
                    </div>
                </div>
            </div>


            <!-- Basic Card Example -->


            <?php if (!$detail_user['alamat']) { ?>
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-secondary">Lengkapi Data Kamu</h6>
                    </div>
                    <div class="card-body">
                        <h2>Hai, <?= $user['name']; ?></h2>
                        <hr>
                        Lengkapi Data Diri kamu dulu sebelum menjual ataupun berbelanja, karena akan memudahkanmu untuk bertransaksi. <br> Silakan klik
                        <a href="<?= base_url('user/detail_user'); ?>" class="btn btn-sm btn-info">Lengkapi Data Dirimu!</a>
                    </div>
                </div>

            <?php } else { ?>

                <hr>
                <a href="<?= base_url('user/detail_user'); ?>" class="btn btn-sm btn-info">Edit Informasi</a>
            <?php } ?>
        </div>
        <div class="col mt-5">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-secondary">Informasi Lengkap</h6>
                </div>
                <div class="card-body">
                    <img src="<?= base_url('assets/img/slider/'); ?>one.svg" class="img-fluid ml-4" style="width: 400px" />

                    <table class="table table-borderless">
                        <tbody>
                            <tr class="d-flex">
                                <td class="col-4">Nama Lengkap</td>
                                <td class="col-1">:</td>
                                <td class="col-7"><?= ucwords($user['name']); ?></td>
                            </tr>
                            <tr class="d-flex">
                                <td class="col-4">E-Mail</td>
                                <td class="col-1">:</td>
                                <td class="col-7"><?= strtolower($user['email']); ?></td>
                            </tr>
                            <tr class="d-flex">
                                <td class="col-4">Tanggal Lahir</td>
                                <td class="col-1">:</td>
                                <td class="col-7"><?= $detail_user['tgl_lahir']; ?></td>
                            </tr>
                            <tr class="d-flex">
                                <td class="col-4">Jenis Kelamin</td>
                                <td class="col-1">:</td>
                                <td class="col-7"><?= ucfirst($detail_user['gender']); ?></td>
                            </tr>
                            <tr class="d-flex">
                                <td class="col-4">Nomor Telepon</td>
                                <td class="col-1">:</td>
                                <td class="col-7"><?= $detail_user['no_telp']; ?></td>
                            </tr>
                            <tr class="d-flex">
                                <td class="col-4">Rekening Bank</td>
                                <td class="col-1">:</td>
                                <td class="col-7"><?= $detail_user['no_bank'] . ' - ' . strtoupper($detail_user['nama_bank']); ?></td>
                            </tr>
                            </tr>
                            <tr class="d-flex">
                                <td class="col-4">Alamat</td>
                                <td class="col-1">:</td>
                                <td class="col-7"><?= $detail_user['alamat']; ?></td>
                            </tr>


                        </tbody>
                    </table>

                </div>
            </div>

        </div>
    </div>




</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->