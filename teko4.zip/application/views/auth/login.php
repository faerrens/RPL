<div class="container">

    <div class="card o-hidden border-0 shadow-lg my-5 col-lg-6 mx-auto" style="border-radius: 20px;">
        <div class="card-body p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">
                <!-- <div class="col-lg-5 d-none d-lg-block bg-register-image"></div> -->
                <div class="col-lg">
                    <div class="p-4">
                        <div class="text-center">
                            <div class="teko"><a href="<?= base_url('homepage'); ?>">
                                    <h2 style="font-size: 35px; font-family: Poppins; font-weight: bold; color: #02925d; text-decoration: none;">TEKO</h2>
                                </a></div>
                            <h1 class="h4 mb-4" style="font-size: 20px; font-family: Arial; font-weight: bold; color: #313131;">Silahkan masuk ke akun kamu</h1>
                            <p class="h4 mb-4" style="font-size: 15px;font-family: 'Muli', sans-serif; color: #313131;">Kamu belum punya akun TEKO? ayo <a href="<?= base_url('auth/registration'); ?>" style="color: #02925d;"><strong>Daftar Disini</strong></a></p>
                        </div>
                        <?= form_open_multipart('auth'); ?>

                        <!-- <div class="col-sm-6 mb-3 mb-sm-0">
                                    <input type="text" class="form-control form-control-user" id="first" name="first" placeholder="First Name">
                                </div>
                                <div class="col-sm-6">
                                    <input type="text" class="form-control form-control-user" id="last" name="last" placeholder="Last Name">
                                </div>
                            </div> -->

                        <?= $this->session->flashdata('message'); ?>



                        <div class="form-group row">
                            <div class="col-lg-12">
                                <input type="text" class="form-control" id="email" name="email" placeholder="Email" value="<?= set_value('email'); ?>">
                                <!-- ini untuk form error -->
                                <?= form_error('email', '<small class="text-danger pl-3">', '</small>'); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-lg-12">
                                <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                                <!-- ini untuk form error -->
                                <?= form_error('password', '<small class="text-danger pl-3">', '</small>'); ?>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-user btn-block" style="background-color: #02925d; color: white !important;">
                            Login
                        </button>
                        <div class="row py-4">
                            <div class="col-sm">
                                <hr>
                            </div>
                            <div class="col-sm" align="center">
                                OR
                            </div>
                            <div class="col-sm">
                                <hr>
                            </div>
                        </div>
                        <!-- <div class="g-signin2" data-onsuccess="onSignIn"></div> -->

                        <a href="index.html" class="btn btn-google btn-user btn-block">
                            <i class="fab fa-google fa-fw"></i> Login with Google
                        </a>
                        <a href="index.html" class="btn btn-facebook btn-user btn-block">
                            <i class="fab fa-facebook-f fa-fw"></i> Login with Facebook
                        </a>

                        <hr>
                        <div class="text-center">
                            <a class="small" href="<?= base_url('auth/forgotpassword'); ?>">Forgot Password?</a>
                        </div>
                        <div class="text-center">
                            <a class="small" href="<?= base_url('auth/registration'); ?>">Belum punya akun? Daftar sekarang!</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>



<!-- Button trigger modal -->
<!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
    Launch demo modal
</button> -->

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                ...
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>