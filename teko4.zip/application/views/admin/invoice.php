<div class="container-fluid">

    <h4>Invoice Pemesanan Komponen</h4>

    <?php
    $check = $this->model_invoice->tampil_data();
    if ($check !== FALSE) { ?>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">

                    <thead>
                        <tr>
                            <th>Id Invoice</th>
                            <th>Nama Pemesan</th>
                            <!-- <th>Komponen</th> -->
                            <th>Alamat Pengiriman</th>
                            <th>Tanggal Pemesanan</th>
                            <th>Batas Pembayaran</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>

                            <?php foreach ($invoice as $inv) : ?>

                                <td><?= $inv->id; ?></td>
                                <td><?= $inv->nama; ?></td>
                                <td><?= $inv->alamat; ?></td>
                                <td><?= $inv->tgl_pesan; ?></td>
                                <td><?= $inv->batas_bayar; ?></td>

                                <!-- panggil controller invoice untuk detail -->
                                <td><?= anchor('user/detail/' . $inv->id, '<div class="btn btn-sm btn-warning">Detail</div>'); ?>

                                </td>
                        </tr>

                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    <?php } else {
        ?>

        <div class="row">
            <div class="col-sm-12">
                <div class="alert alert-info" role="alert">

                    <h4 class="alert-heading">HAI...</h4>
                    <hr>
                    <p>Admin seseorang masih belum memiliki pesanan apapun, silahkan cek lagi databasenya <a class="badge badge-secondary" href="<?= base_url('homepage'); ?>">disini</a> untuk membeli yang kamu butuhkan :)</p>
                </div>
            </div>
        </div>

    <?php }
    ?>
</div>

</div>