<div class="container-fluid">
    <h3><i class="fas fa-edit"></i> EDIT DATA KOMPONEN</h3>
    <?php foreach ($komponen as $kom) : ?>
        <form action="<?= base_url('admin/update') ?>" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="">Nama Komponen</label>
                <input type="text" name="nama_komponen" class="form-control" value="<?= $kom->nama_komponen ?>">
                <input type="hidden" name="id_komponen" class="form-control" value="<?= $kom->id_komponen ?>">
            </div>
            <div class="form-group">
                <label for="">Manufaktur</label>
                <input type="text" name="manufacture" class="form-control" value="<?= $kom->manufacture ?>">
            </div>

            <div class="form-group">
                <label for="">Deskripsi</label>
                <input type="text" name="deskripsi" class="form-control" value="<?= $kom->deskripsi ?>">
            </div>
            <div class="form-group">
                <label for="">Kategori</label>
                <input type="text" name="kategori" id="kategori" class="form-control" value="<?= $kom->kategori ?>" />
            </div>
            <div class="form-group">
                <label for="">Harga</label>
                <input type="text" name="harga" class="form-control" value="<?= $kom->harga ?>">
            </div>
            <div class="form-group">
                <label for="">Jumlah Stok</label>
                <input type="text" name="stok" class="form-control" value="<?= $kom->stok ?>">
            </div>
            <div class="form-group">
                <label for="image">Gambar</label>
                <div class="custom-file">
                    <input type="file" class="custom-file-input" id="image" name="image" />
                    <label class="custom-file-label" for="image">Pilih gambar</label>
                </div>
            </div>
            <div class="form-group">
                <label for="">Date</label>
                <input type="text" name="date_created" class="form-control" value="<?= $kom->date_created ?>">
            </div>


            <button type="submit" class="btn btn-success btn-sm">Simpan</button>
        </form>
    <?php endforeach; ?>
</div>