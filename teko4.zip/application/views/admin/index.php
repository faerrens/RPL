<!-- Begin Page Content -->
<div class="container-fluid">

    <style>
        td {
            word-break: break-all;
        }
    </style>
    <?php echo $this->session->flashdata('message'); ?>
    <button class="btn btn-sm btn-success mb-3" data-toggle="modal" data-target="#exampleModalCenter"><i class="fas fa-plus fa-sm"></i> Tambah Komponen Manual sebagai Administrator</button>



    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">

                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Komponen</th>
                        <th>Manufacture</th>
                        <th>Deskripsi</th>
                        <th>Kategori</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th>Image</th>
                        <th>Date</th>
                        <th>Look</th>
                        <th>Edit Manual</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>

                    <?php
                    $no = 1;
                    foreach ($komponen as $kom) : ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $kom->nama_komponen; ?></td>
                            <td><?= $kom->manufacture; ?></td>
                            <td><?= $kom->deskripsi; ?></td>
                            <td><?= $kom->kategori; ?></td>
                            <td><?= $kom->harga; ?></td>
                            <td><?= $kom->stok; ?></td>
                            <td><?= $kom->image; ?></td>
                            <td><?= $kom->date_created; ?></td>
                            <td>
                                <div class="btn btn-success btn-md btn-circle" btn-sm><i class="fas fa-search-plus"></i></div>
                            </td>
                            <td>
                                <?php echo anchor('admin/edit/' . $kom->id_komponen, '<div class="btn btn-info btn-md btn-circle"><i class="fas fa-edit"></i></div>'); ?>
                            </td>
                            <td>
                                <?php echo anchor('admin/hapus/' . $kom->id_komponen, '<div class="btn btn-danger btn-md btn-circle"><i class="fas fa-trash"></i></div>'); ?>
                            </td>
                        </tr>

                    <?php endforeach;
                    ?>

                </tbody>
            </table>
        </div>
    </div>



</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->


<!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Masukkan data komponen untuk dipamerkan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?= form_open_multipart('admin/tambah_aksi'); ?>
                <div class="form-group">
                    <label for="">Nama Komponen</label>
                    <input type="text" name="nama_komponen" class="form-control">
                </div>
                <div class="form-group">
                    <label for="">Manufacture</label>
                    <input type="text" name="manufacture" class="form-control">
                </div>

                <div class="form-group">
                    <label for="">Deskripsi</label>
                    <input type="text" name="deskripsi" class="form-control">
                </div>
                <div class="form-group">
                    <label for="">Kategori</label>
                    <input type="text" name="kategori" class="form-control">
                </div>
                <div class="form-group">
                    <label for="">Harga</label>
                    <input type="text" name="harga" class="form-control">
                </div>
                <div class="form-group">
                    <label for="">Stok</label>
                    <input type="text" name="stok" class="form-control">
                </div>
                <div class="form-group">
                    <label for="">Gambar Komponen</label><br>
                    <input type="file" name="image" class="form-control">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-success">Pamerin</button>
            </div>
        </div>
    </div>
</div>