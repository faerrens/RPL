<div class="container-fluid">
    <!-- memanfaatkan grid agar form tidak terlalu besar dan bisa ditempatkan ditengah -->
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <div class="btn btn-sm btn-success">
                <?php $grand_total = 0;
                //jika keranjang belanjanya ada isinya maka kita akan menghitung grandtotalnhya
                if ($keranjang = $this->cart->contents()) {
                    foreach ($keranjang as $item) {
                        $grand_total = $grand_total + $item['subtotal'];
                    }

                    echo "<h3>Total Belanja Kamu: Rp. " . number_format($grand_total, 0, ',', '.');
                    ?>
            </div>
            <div>
                <h3>Input Alamat Pengiriman dan Pembayaran</h3>

                <form action="<?= base_url('homepage/proses_pesanan') ?>" method="post">

                    <div class="form-group">
                        <label for="">Nama Lengkap</label>
                        <input type="text" name="nama" placeholder="e.g., David Pratama" class="form-control" value="<?= $detail_user['name']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="">Alamat Lengkap</label>
                        <input type="text" name="alamat" placeholder="e.g., Jalan AMD V no. 82a" class="form-control" value="<?= $detail_user['alamat']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="">Nomor Telepon</label>
                        <input type="text" name="notelp" placeholder="e.g., Nomor Telepon Kamu" class="form-control" value="<?= $detail_user['no_telp']; ?>">
                    </div>
                    <div class="form-group">
                        <label for="kurir">Jasa Pengiriman</label>
                        <select name="kurir" id="kurir" class="form-control">
                            <option value="JNE">JNE</option>
                            <option value="TIKI">TIKI</option>
                            <option value="JTE">JTE</option>
                            <option value="SICEPAT">Si Cepat</option>
                            <option value="POS">POS Indonesia</option>
                            <option value="GOJEK">GO-JEK</option>
                            <option value="GRAB">GRAB</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="pilihan">Pilih Bank / Metode Pembayaran</label>
                        <select name="pilihan" id="pilihan" class="form-control">
                            <option value="bca">BCA - XXXXXXXXXXX</option>
                            <option value="bni">BNI - XXXXXXXXXXX</option>
                            <option value="bri">BRI - XXXXXXXXXXX</option>
                            <option value="mandiri">Mandiri - XXXXXXXXXXXX</option>
                            <option value="gopay">Gopay - XXXXXXXXXXXX</option>
                            <option value="ovo">OVO - XXXXXXXXXXXX</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-sm btn-info">Pesan</button>
                </form>
            <?php } else { ?>

                <button class="btn btn-sm btn-success text-center">
                    <h5>Keranjang Belanja Kamyu masih kosong :)</h5>
                </button>
            <?php } ?>
            <br><br><br>
            </div>

            <div class="col-md-2"></div>
        </div>
    </div>

</div>

<!-- Modal -->
<!-- Modal -->
<!-- ------- LOGIN ------- -->
<div class="modal fade" id="LogInModal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Sign In</h5>
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('authh') ?>" method="post" class="needs-validation" novalidate>
                    <!-- Form Title -->
                    <div class="text-center py-2">
                        <div class="title text-success">
                            <h1><strong>TEKO</strong></h1>
                        </div>
                        <!-- Social Line -->

                    </div>



                    <div class="text-center py-3">

                        <a href="#"><i class="fab fa-facebook fa-3x px-2"></i></a>
                        <a href="#"><i class="fab fa-google-plus fa-3x px-2"></i></a>
                        <a href="#"><i class="fab fa-twitter fa-3x px-2"></i></a>
                    </div>
                    <div class="form-group row py-2 mt-2">
                        <label for="email" class="col-sm-2 col-form-label fa-fw"><i class="fas fa-envelope"></i></label>
                        <div class="col-sm-9">
                            <input value="<?= set_value('email'); ?>" type=" email" class="form-control" name="email" id="email" placeholder="Email" aria-describedby="emailHelp" required>
                            <div class="invalid-feedback">
                                Please enter a valid email address
                            </div>
                        </div>
                    </div>
                    <div class="form-group row mt-2">
                        <label for="password" class="col-sm-2 col-form-label fa-fw"><i class="fas fa-unlock-alt"></i></label>
                        <div class="col-sm-9">
                            <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
                            <div class="invalid-feedback">
                                Please enter a password
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-4">
                            <input type="checkbox" />
                            <label>Remember Me</label>
                        </div>
                        <div class="col-md-1 ml-4"></div>
                        <div class="">
                            <label><a href="<?= base_url('auth/forgotpassword'); ?>">Forget Password?</a></label>
                        </div>

                    </div>


                    <div class="row py-4">
                        <div class="col-md-12 text-center">

                            <!-- button with onclick event that triggers the form validation. If the form is valid, triggers click of second button -->


                            <!-- hidden submit button -->
                            <button type="submit" class="btn btn-lg btn-success">Sign In</button>

                        </div>
                    </div>
                </form>
                <div class="row py-3">
                    <div class="col-md-12 text-center">
                        <a href="<?= base_url('auth/registration'); ?>">Belum punya akun? Buat sekarang!</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ------- LOGIN Ends ------- -->
</div>