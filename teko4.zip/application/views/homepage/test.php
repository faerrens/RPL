<form method="post" action="<?= base_url('homepage/action'); ?>" class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
    <div class="input-group">
        <input type="text" id="search" name="search" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
        <div class="input-group-append">
            <button class="btn btn-success" type="submit">
                <i class="fas fa-search fa-sm"></i>
            </button>
        </div>
    </div>
</form>
<div class="col-md-4" style="position: absolute; margin-top: -37px; margin-left: -5px; z-index: 99;">
    <div class="list-group" id="show-list">

    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $("$search").keyup(function() {
            var searchText = $(this).val();
            if (searchText != '') {
                $.ajax({
                    url: '<?= base_url('homepage/action'); ?>',
                    method: 'post',
                    data: {
                        query: searchText
                    },
                    success: function(response) {
                        $("#show-list").html(response);
                    }
                });
            } else {
                $("#show-list").html('');
            }
        });
        $(document).on('click', 'a', function() {
            $("#search").val($(this).text());
            $("#show-list").html('');
        });
    });
</script>