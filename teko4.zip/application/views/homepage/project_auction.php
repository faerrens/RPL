<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">





        <!-- Begin Page Content CONTENT CONTENT DALEM ISI HEHE -->
        <div class="container-fluid">

            <!-- CAROUSEL SLIDER HEHEHEHE -->

            <!-- Button trigger modal -->

            <!-- Modal -->
            <!-- Modal -->
            <!-- ------- LOGIN ------- -->
            <div class="modal fade" id="LogInModal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Sign In</h5>
                            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?= base_url('authh') ?>" method="post" class="needs-validation" novalidate>
                                <!-- Form Title -->
                                <div class="text-center py-2">
                                    <div class="title text-success">
                                        <h1><strong>TEKO</strong></h1>
                                    </div>
                                    <!-- Social Line -->

                                </div>



                                <div class="text-center py-3">

                                    <a href="#"><i class="fab fa-facebook fa-3x px-2"></i></a>
                                    <a href="#"><i class="fab fa-google-plus fa-3x px-2"></i></a>
                                    <a href="#"><i class="fab fa-twitter fa-3x px-2"></i></a>
                                </div>
                                <div class="form-group row py-2 mt-2">
                                    <label for="email" class="col-sm-2 col-form-label fa-fw"><i class="fas fa-envelope"></i></label>
                                    <div class="col-sm-9">
                                        <input value="<?= set_value('email'); ?>" type=" email" class="form-control" name="email" id="email" placeholder="Email" aria-describedby="emailHelp" required>
                                        <div class="invalid-feedback">
                                            Please enter a valid email address
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row mt-2">
                                    <label for="password" class="col-sm-2 col-form-label fa-fw"><i class="fas fa-unlock-alt"></i></label>
                                    <div class="col-sm-9">
                                        <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
                                        <div class="invalid-feedback">
                                            Please enter a password
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2"></div>
                                    <div class="col-md-4">
                                        <input type="checkbox" />
                                        <label>Remember Me</label>
                                    </div>
                                    <div class="col-md-1 ml-4"></div>
                                    <div class="">
                                        <label><a href="<?= base_url('auth/forgotpassword'); ?>">Forget Password?</a></label>
                                    </div>

                                </div>


                                <div class="row py-4">
                                    <div class="col-md-12 text-center">

                                        <!-- button with onclick event that triggers the form validation. If the form is valid, triggers click of second button -->


                                        <!-- hidden submit button -->
                                        <button type="submit" class="btn btn-lg btn-success">Sign In</button>

                                    </div>
                                </div>
                            </form>
                            <div class="row py-3">
                                <div class="col-md-12 text-center">
                                    <a href="<?= base_url('auth/registration'); ?>">Belum punya akun? Buat sekarang!</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ------- LOGIN Ends ------- -->

            <?php if ($this->session->flashdata('message')) { ?>


                <div class="alert alert-success text-center py-0 px-0 mx-0 mb-3" role="alert">
                    <p><?php echo $this->session->flashdata('message'); ?></p>
                </div>


            <?php } ?>

            <?= form_error('email', '<small class="text-danger pl-3">', '</small>'); ?>
            <?= form_error('password', '<small class="text-danger pl-3">', '</small>'); ?>





            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="<?= base_url('assets/img/slider/slider1.jpg'); ?>" class="d-block w-100" alt="...">
                    </div>
                    <div class="carousel-item">
                        <img src="<?= base_url('assets/img/slider/slider2.jpg'); ?>" class="d-block w-100" alt="...">
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
            <!-- Page Heading -->

            <div class="row text-center mx-auto mt-4">
                <?php foreach ($project_auction as $kom) : ?>
                    <div class="card shadow mx-auto mb-3">
                        <div class="card-body">
                            <?= anchor('homepage/detail/' . $kom->id_komponen, '<img src="' . base_url('assets/img/item/') . $kom->image . '"style="width: 210px; height: 210px;" class="card-img-top" alt="...">'); ?>
                            <?= anchor('homepage/detail/' . $kom->id_komponen, '<h6 class="card-title mb-1">' . character_limiter($kom->nama_komponen, 15) . '</h6>'); ?>
                            <small><?= character_limiter($kom->deskripsi, 25); ?></small><br>
                            <span class="badge badge-success mb-3">Rp. <?= number_format($kom->harga, 0, ',', '.'); ?></span><br>
                            <!-- untuk tambah masukin data ke kranjang-->
                            <?= anchor('homepage/tambah_ke_keranjang/' . $kom->id_komponen, '<div class="btn btn-sm btn-info"><i class="fas fa-plus"></i> Keranjang</div>'); ?>
                            <?= anchor('homepage/detail/' . $kom->id_komponen, '<div class="btn btn-sm btn-warning">Detail</div>'); ?>

                        </div>
                    </div>
                <?php endforeach; ?>
            </div>



        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->



</div>
<!-- End of Content Wrapper -->

<!-- Button trigger modal -->
<!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
    Launch demo modal
</button> -->

<!-- Modal -->
<!-- <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                ...
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div> -->