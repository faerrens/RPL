<div class="container-fluid">

    <div class="card">
        <h5 class="card-header">Detail Komponen</h5>
        <div class="card-body">

            <!-- grid system -->
            <?php foreach ($komponen as $kom) : ?>
                <div class="row">
                    <div class="col-md-4">
                        <!-- tampilan class= card-img-top untuk memperkecil gambar yang besar dimasukkan ke card img -->
                        <img src="<?= base_url('assets/img/item/' . $kom->image); ?>" alt="" class="card-img-top">
                    </div>
                    <div class="col-md-8">
                        <table class="table table-md table-hover">
                            <tr>
                                <td>Nama Komponen/Project IoT</td>
                                <td><strong><?= $kom->nama_komponen; ?></strong></td>
                            </tr>
                            <tr>
                                <td>Diproduksi oleh</td>
                                <td><strong><?= $kom->manufacture; ?></strong></td>
                            </tr>
                            <tr>
                                <td>Deskripsi</td>
                                <td><strong><?= $kom->deskripsi; ?></strong></td>
                            </tr>
                            <tr>
                                <td>Kategori</td>
                                <td><strong><?= $kom->kategori; ?></strong></td>
                            </tr>
                            <tr>
                                <td>Harga</td>
                                <td><strong><button class="btn btn-success">Rp. <?= number_format($kom->harga, 0, ',', ','); ?></button></strong></td>
                            </tr>
                            <tr>
                                <td>Stok</td>
                                <td><strong><?= $kom->stok; ?></strong></td>
                            </tr>
                            <tr>
                                <td>Dipamerkan sejak</td>
                                <td><strong><?= date('D, d M Y', $kom->date_created); ?></strong></td>
                            </tr>
                            <tr>
                                <?php $query = "SELECT `u`.`name` FROM `user` `u`, `jual` `j`,`komponen` `k` WHERE `u`.`id` = `j`.`id_customer` AND `k`.`id_komponen` = `j`.`id_komponen` AND `j`.`id_komponen` = $kom->id_komponen";
                                
                                $result = $this->db->query($query); ?>
                                
                                <td>Dipamerkan oleh</td>
                                <td><strong><?php foreach($result->result() as $r){echo $r->name;} ?></strong></td>
                            </tr>

                         

                        </table>

                        <?= anchor('homepage/tambah_ke_keranjang_2/' . $kom->id_komponen, '<div class="btn btn-sm btn-info"><i class="fas fa-plus"></i> Checkout</div>'); ?>
                        <a href="<?= base_url('homepage') ?>">
                            <div class="btn btn-sm btn-success">Kembali</div>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>




    </div>
    <!-- Modal -->
    <!-- Modal -->
    <!-- ------- LOGIN ------- -->
    <div class="modal fade" id="LogInModal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Sign In</h5>
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
                </div>
                <div class="modal-body">
                    <form action="<?= base_url('authh') ?>" method="post" class="needs-validation" novalidate>
                        <!-- Form Title -->
                        <div class="text-center py-2">
                            <div class="title text-success">
                                <h1><strong>TEKO</strong></h1>
                            </div>
                            <!-- Social Line -->

                        </div>



                        <div class="text-center py-3">

                            <a href="#"><i class="fab fa-facebook fa-3x px-2"></i></a>
                            <a href="#"><i class="fab fa-google-plus fa-3x px-2"></i></a>
                            <a href="#"><i class="fab fa-twitter fa-3x px-2"></i></a>
                        </div>
                        <div class="form-group row py-2 mt-2">
                            <label for="email" class="col-sm-2 col-form-label fa-fw"><i class="fas fa-envelope"></i></label>
                            <div class="col-sm-9">
                                <input value="<?= set_value('email'); ?>" type=" email" class="form-control" name="email" id="email" placeholder="Email" aria-describedby="emailHelp" required>
                                <div class="invalid-feedback">
                                    Please enter a valid email address
                                </div>
                            </div>
                        </div>
                        <div class="form-group row mt-2">
                            <label for="password" class="col-sm-2 col-form-label fa-fw"><i class="fas fa-unlock-alt"></i></label>
                            <div class="col-sm-9">
                                <input type="password" class="form-control" name="password" id="password" placeholder="Password" required>
                                <div class="invalid-feedback">
                                    Please enter a password
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2"></div>
                            <div class="col-md-4">
                                <input type="checkbox" />
                                <label>Remember Me</label>
                            </div>
                            <div class="col-md-1 ml-4"></div>
                            <div class="">
                                <label><a href="<?= base_url('auth/forgotpassword'); ?>">Forget Password?</a></label>
                            </div>

                        </div>


                        <div class="row py-4">
                            <div class="col-md-12 text-center">

                                <!-- button with onclick event that triggers the form validation. If the form is valid, triggers click of second button -->


                                <!-- hidden submit button -->
                                <button type="submit" class="btn btn-lg btn-success">Sign In</button>

                            </div>
                        </div>
                    </form>
                    <div class="row py-3">
                        <div class="col-md-12 text-center">
                            <a href="<?= base_url('auth/registration'); ?>">Belum punya akun? Buat sekarang!</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ------- LOGIN Ends ------- -->
</div>
</div>