<h2 style="color: black;">Hai, terima kasih telah menjadi penjual yang terpercaya, silahkan lihat pembelimu dulu yuk.. beli apa aja ya?</h2>
<table class="greenTable" style="font-family: Tahoma, Geneva, sans-serif;
        border: 0px solid #B4C0C1;
        background-color: #EEEEEE;
        width: 100%;
        text-align: center;">
    <thead style="        background: #B4C0C1;
        background: -moz-linear-gradient(top, #c7d0d0 0%, #bbc6c7 66%, #B4C0C1 100%);
        background: -webkit-linear-gradient(top, #c7d0d0 0%, #bbc6c7 66%, #B4C0C1 100%);
        background: linear-gradient(to bottom, #c7d0d0 0%, #bbc6c7 66%, #B4C0C1 100%);
        border-bottom: 0px solid #444444;">
        <tr>
            <th colspan="9" style=" border: 1px solid #B4C0C1;
        padding: 10px 6px; font-weight: bold;
        color: #F0F0F0;
        text-align: center;"><strong>Pembelimu</strong></th>
        </tr>
        <tr class="text-center">
            <th style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;         font-weight: bold;
        color: #F0F0F0;
        text-align: center;">name</th>
            <th style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;         font-weight: bold;
        color: #F0F0F0;
        text-align: center;">komponen</th>
            <th style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;         font-weight: bold;
        color: #F0F0F0;
        text-align: center;">harga</th>
            <th style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;         font-weight: bold;
        color: #F0F0F0;
        text-align: center;">jumlah</th>
            <th style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;         font-weight: bold;
        color: #F0F0F0;
        text-align: center;">alamat</th>
            <th style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;         font-weight: bold;
        color: #F0F0F0;
        text-align: center;">tanggal pesan</th>
            <th style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;         font-weight: bold;
        color: #F0F0F0;
        text-align: center;">kurir</th>
            <th style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;         font-weight: bold;
        color: #F0F0F0;
        text-align: center;">nomor telp</th>
            <th style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;         font-weight: bold;
        color: #F0F0F0;
        text-align: center;">subtotal</th>
        </tr>
    </thead>

    <?php

    $total = 0;

    $test = "   SELECT k.id_komponen FROM komponen k, jual j, user u WHERE j.id_komponen = k.id_komponen AND j.id_customer = u.id AND k.id_customer = u.id AND u.email = '$email_penjual'
                INTERSECT 
                SELECT p.id_komponen FROM pesanan p WHERE p.id_invoice = $id";
    $test = $this->db->query($test)->result_array();



    foreach ($test as $t) {
        $tos = [
            'id' . $t['id_komponen'] => $t['id_komponen']
        ];
    }







    $query = "SELECT *, `k`.`id_customer` AS penjual FROM `user` `u`, `pesanan` `p`, `komponen` `k`, `invoice` `i`, `detail_user` `d` WHERE `p`.`id_komponen` = `k`.`id_komponen` AND `p`.`id_customer` = `u`.`id` AND `p`.`id_invoice` = `i`.`id` AND `d`.`id` = `u`.`id` AND `k`.`id_komponen` IN(" . implode(',', $tos) . ")  AND `p`.`id_invoice` =" . $this->session->userdata('id_invoice' . $id);

    $result = $this->db->query($query);


    foreach ($result->result_array() as $q) { ?>
        <tbody>
            <tr>
                <td style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;"> <?= $q['nama'] ?></td>
                <td style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;"> <?= $q['nama_komponen'] ?></td>
                <td style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;">Rp. <?= number_format($q['harga'], 0, ',', '.'); ?></td>
                <td style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;"><?= $q['jumlah'] ?></td>
                <td style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;"><?= $q['alamat'] ?></td>
                <td style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;"><?= $q['tgl_pesan'] ?></td>
                <td style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;"><?= $q['kurir'] ?></td>
                <td style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;"><?= $q['no_telp'] ?></td>

                <td style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;">Rp. <?= number_format($q['jumlah'] * $q['harga'], 0, ',', '.'); ?></td>
            </tr>

            <tr>
            <?php $total = $total + $q['jumlah'] * $q['harga'];
            } ?>

            <td style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;" colspan="8" align="right">Total : </td>
            <td style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;" align="right">Rp. <?= number_format($total, 0, ',', '.'); ?></td>
            </tr>
        </tbody>

</table>