<div class="navbar">

    <div class="teko"><a href="#">
            <h2>TEKO</h2>
        </a></div>

    <div class="icon">
        <div class="category-icon"><a href="#"><img src="<?= base_url('assets/img/cat.png') ?>"></a></div>
        <div class="cart-icon"><a href="#"><img src="<?= base_url('assets/img/cart.png') ?>" class="invert"></a></div>
    </div>

    <div class="kategori"><a href="#">
            <h2>Kategori</h2>
        </a></div>

    <form action="index.php">
        <div class="search">
            <div class="srch-icon"></div>
            <input type="text" name="srchbox" autocomplete="off" placeholder="Search item you need...">
        </div>
    </form>

    <div class="auth">
        <a href="<?= base_url('auth') ?>" class="log">
            <div class="login-btn">Login</div>
        </a>
        <a href="<?= base_url('auth/registration') ?>" class="reg">
            <div class="register-btn">Register</div>
        </a>
    </div>
</div>

<div class="container">

    <div class="content cf">

        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
            consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
            cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
            proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

        <!-- Modal -->
        <div class="modal fade" id="darkModalForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog form-dark" role="document">
                <!--Content-->
                <div class="modal-content card card-image" style="background-image: url('https://mdbootstrap.com/img/Photos/Others/pricing-table%20(7).jpg');">
                    <div class="text-white rgba-stylish-strong py-5 px-5 z-depth-4">
                        <!--Header-->
                        <div class="modal-header text-center pb-4">
                            <h3 class="modal-title w-100 white-text font-weight-bold" id="myModalLabel"><strong>SIGN</strong> <a class="green-text font-weight-bold"><strong> UP</strong></a></h3>
                            <button type="button" class="close white-text" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <!--Body-->
                        <div class="modal-body">
                            <!--Body-->
                            <div class="md-form mb-5">
                                <input type="email" id="Form-email5" class="form-control validate white-text">
                                <label data-error="wrong" data-success="right" for="Form-email5">Your email</label>
                            </div>

                            <div class="md-form pb-3">
                                <input type="password" id="Form-pass5" class="form-control validate white-text">
                                <label data-error="wrong" data-success="right" for="Form-pass5">Your password</label>
                                <div class="form-group mt-4">
                                    <input class="form-check-input" type="checkbox" id="checkbox624">
                                    <label for="checkbox624" class="white-text form-check-label">Accept the<a href="#" class="green-text font-weight-bold">
                                            Terms and Conditions</a></label>
                                </div>
                            </div>

                            <!--Grid row-->
                            <div class="row d-flex align-items-center mb-4">

                                <!--Grid column-->
                                <div class="text-center mb-3 col-md-12">
                                    <button type="button" class="btn btn-success btn-block btn-rounded z-depth-1">Sign up</button>
                                </div>
                                <!--Grid column-->

                            </div>
                            <!--Grid row-->

                            <!--Grid row-->
                            <div class="row">

                                <!--Grid column-->
                                <div class="col-md-12">
                                    <p class="font-small white-text d-flex justify-content-end">Have an account? <a href="#" class="green-text ml-1 font-weight-bold">
                                            Log in</a></p>
                                </div>
                                <!--Grid column-->

                            </div>
                            <!--Grid row-->

                        </div>
                    </div>
                </div>
                <!--/.Content-->
            </div>
        </div>
        <!-- Modal -->

        <div class="text-center">
            <a href="" class="btn btn-default btn-rounded" data-toggle="modal" data-target="#darkModalForm">Launch modal register Form</a>
        </div>

    </div>