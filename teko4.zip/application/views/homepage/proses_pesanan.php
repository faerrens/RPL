<div class="container-fluid">

    <div class="alert alert-success text-center">
        Selamat, Pesanan Kamu berhasil diproses!! <a href="<?= base_url('user/invoice') ?>">
            <div class="badge badge-info badge-lg p-2">Lihat Invoice</div>
        </a>
    </div>

</div>
</div>