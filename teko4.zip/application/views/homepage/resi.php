<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <style>
        ::-webkit-input-placeholder {
            text-align: center;
        }

        :-moz-placeholder {
            /* Firefox 18- */
            text-align: center;
        }

        ::-moz-placeholder {
            /* Firefox 19+ */
            text-align: center;
        }

        :-ms-input-placeholder {
            text-align: center;
        }
    </style>

    <title>RESI</title>


</head>

<body>
    <div class="container">


        <div class="card text-center" style="margin-top: 15%;">
            <div class="card-header">
                Nomor Resi untuk No. Invoice : #
                <?= $id; ?>
            </div>
            <div class="card-body text-center">
                <h5 class="card-title">Masukkan Nomor Resi Agen Ekspedisi</h5>
                <form action="<?= base_url('homepage/resi'); ?>">
                    <p class="card-text">Nomor resi akan sangat dibutuhkan oleh pembeli kamu untuk melacak status pesanan, maka dari itu silakan isi nomor resi kamu</p>
                    <input type="text" id="resi" name="resi" required placeholder="Masukkan no. resi" class="form-control" />
                    <input type="hidden" id="id" name="id" value="<?= $id ?>" />
                    <input type="hidden" id="id_komponen" name="id_komponen" value="<?= $id_komponen ?>" />
                    <button type="submit" class="btn btn-success btn-md mt-3">Simpan</button?>
                </form>
            </div>
            <div class="card-footer text-muted">
                Atau kamu bisa mengisinya di tab pembeli: <a href="<?= base_url('user'); ?>">
                    <div class="btn btn-md btn-info">Penjualan</div>
                </a>
            </div>
        </div>


    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>

</html>