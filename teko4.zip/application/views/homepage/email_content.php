<h2 style="color: black;">Hai, terima kasih atas kepercayaannya untuk berbelanja segala komponen dan project IoT di TEKO, segera lakukan pembayaranmu sesuai dengan invoice yang tertera di bawah ini ya :)</h2>
<table class="greenTable" style="font-family: Tahoma, Geneva, sans-serif;
        border: 0px solid #B4C0C1;
        background-color: #EEEEEE;
        width: 100%;
        text-align: center;">
    <thead style="        background: #B4C0C1;
        background: -moz-linear-gradient(top, #c7d0d0 0%, #bbc6c7 66%, #B4C0C1 100%);
        background: -webkit-linear-gradient(top, #c7d0d0 0%, #bbc6c7 66%, #B4C0C1 100%);
        background: linear-gradient(to bottom, #c7d0d0 0%, #bbc6c7 66%, #B4C0C1 100%);
        border-bottom: 0px solid #444444;">
        <tr>
            <th colspan="4" style=" border: 1px solid #B4C0C1;
        padding: 10px 6px; font-weight: bold;
        color: #F0F0F0;
        text-align: center;"><strong>Pembelianmu</strong></th>
        </tr>
        <tr class="text-center">
            <th style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;         font-weight: bold;
        color: #F0F0F0;
        text-align: center;">name</th>
            <th style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;         font-weight: bold;
        color: #F0F0F0;
        text-align: center;">harga</th>
            <th style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;         font-weight: bold;
        color: #F0F0F0;
        text-align: center;">jumlah</th>
            <th style=" border: 1px solid #B4C0C1;
        padding: 10px 6px; font-weight: bold;
        color: #F0F0F0;
        text-align: center;">subtotal</th>
        </tr>
    </thead>

    <?php foreach ($this->cart->contents() as $items) : ?>
        <tbody></tbody>
        <tr>
            <td style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;"> <?= $items['name'] ?></td>
            <td style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;">Rp. <?= number_format($items['price'], 0, ',', '.'); ?></td>
            <td style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;"><?= $items['qty'] ?></td>
            <td style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;">Rp. <?= number_format($items['subtotal'], 0, ',', '.'); ?></td>
        </tr><?php endforeach; ?>
    <tr>
        <td style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;" colspan="3" align="right">Total : </td>
        <td style=" border: 1px solid #B4C0C1;
        padding: 10px 6px;" align="right">Rp. <?= number_format($this->cart->total(), 0, ',', '.'); ?></td>
    </tr>
    </tbody>
</table>