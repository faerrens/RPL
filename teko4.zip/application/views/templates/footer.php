<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; TEKO RPL <?= date('Y'); ?></span>
        </div>
    </div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal javascript-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Apakah kamu yakin untuk keluar?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Silakan klik "Logout" jika kamu ingin keluar.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-success" href="<?= base_url('auth/logout'); ?>">Logout</a>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap core JavaScript-->
<script src="<?= base_url('assets/'); ?>vendor/jquery/jquery.min.js"></script>
<script src="<?= base_url('assets/'); ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="<?= base_url('assets/'); ?>vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="<?= base_url('assets/'); ?>js/sb-admin-2.min.js"></script>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<!-- Page level plugins -->
<script src="<?= base_url('assets/'); ?>vendor/datatables/jquery.dataTables.min.js"></script>
<script src="<?= base_url('assets/'); ?>vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="<?= base_url('assets/'); ?>js/demo/datatables-demo.js"></script>

<script>
    $(function() {
        $("#picker").datepicker();
    });
</script>


<script>
    $('.custom-file-input').on('change', function() {
        let fileName = $(this).val().split('\\').pop();
        $(this).next('.custom-file-label').addClass("selected").html(fileName);
    });

    $('.form-check-input').on('click', function() {
        const menuId = $($this).data('menu');
        const roleId = $($this).data('role');
    });
</script>

<script>
    function onSignIn(googleUser) {
        var profile = googleUser.getBasicProfile();
        console.log('ID: ' + profile.getId()); // Do not send to your backend! Use an ID token instead.
        var id = profile.getId();
        console.log('Name: ' + profile.getName());
        var name = profile.getName();
        console.log('Image URL: ' + profile.getImageUrl());
        var image = profile.getImageUrl();
        console.log('Email: ' + profile.getEmail()); // This is null if the 'email' scope is not present.
        var email = profile.getEmail();
    }
</script>

<script>
    $(document).ready(function() {

        $('#dataTable').DataTable({
            destroy: true,
            pagination: true,
            "order": [
                [0, "desc"]
            ]
        });
    });
</script>




<script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>

<script>
    $("a[href='#bottom']").click(function() {
        $("html, body").animate({
            scrollTop: $(document).height()
        }, "slow");
        return false;
    });
</script>

<?php

// $email = "<script>document.writeln(email);</script>";
// $name = "<script>document.writeln(name);</script>";
// $image = "<script>document.writeln(image);</script>";
// $id = "<script>document.writeln(id);</script>";
?>

<?php //if ($email || $name || $image || $id) :
?>

<!-- <form action="<= base_url('auth/_logingoogle'); ?>" method="post"></form>
<input type="hidden" name="email" id="email" value="<= $email; ?>" />
<input type="hidden" name="name" id="name" value="<= $name; ?>" />
<input type="hidden" name="image" id="image" value="<= $image; ?>" />
<input type="hidden" name="id" id="id" value="<= $id; ?>" /> -->
<?php
// $data = [
//     'id' => $id,
//     'name' => $name,
//     'email' => $email,
//     'image' => $image,
//     //'password' => $this->input->post('password1'),
//     'password' => '',   //ini untuk pake hash enkripsi
//     'role_id' => 2, //defaultnya member
//     'is_active' => 1, //nnti bakal ada user activation yang defaultnya 0
//     'date_created' => time()
// ];



// $id = $this->db->get_where('user', ['role_id' => $role_id])->row_array();

// $data2 = array(
//     'id' => $user_role['id'],
//     'role' => $user_role['role']

// );

// $this->db->insert('user_role', $data2);

//lalu simpan data tadi ke dalam session supaya bisa dipanggil ke controller lain/field lain
// $this->db->insert('user', $data);
// $this->session->set_userdata($data); //set variable data//endif; 
?>
<script src="<?= base_url('assets/'); ?>vendor/bootstrap/js/bootstrap-input-spinner.js"></script>
<script>
    $("input[type='number']").inputSpinner()
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.0/clipboard.min.js"></script>

<script>
    $(document).ready(function() {

        new ClipboardJS('.btn');

    });
</script>

<!-- <script src="<php echo base_url() . 'assets/js/jquery-ui.js' ?>" type="text/javascript"></script>
<script src="<php echo base_url() . 'assets/js/jquery-3.3.1.js' ?>" type="text/javascript"></script>
<script src="<php echo base_url() . 'assets/js/bootstrap.js' ?>" type="text/javascript"></script> -->



</body>

</html>