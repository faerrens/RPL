<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-success sidebar sidebar-dark accordion toggled" id="accordionSidebar wrapper">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url('') ?>">
        <div class="sidebar-brand-icon">
            <i class="fas fa-robot"></i>
        </div>
        <div class="sidebar-brand-text mx-3">TEKO</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('homepage') ?>">
            <img src="https://img.icons8.com/officel/30/000000/home.png">
            <span>Dashboard</span></a>
    </li>


    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
        Kategori
    </div>

    <!-- Nav Item - Charts -->

    <?php

    $query = "SELECT * FROM `kategori`";
    $kateg = $this->db->query($query)->result_array();

    ?>

    <?php foreach ($kateg as $ka) : ?>
        <!-- Nav Item - Dashboard -->
        <?php if ($title == $ka['title']) { ?>
            <li class="nav-item active p-2">
            <?php } else { ?>
            <li class="nav-item">
            <?php } ?>
            <a class="nav-link" href="<?= base_url($ka['url']); ?>   ">
                <!-- ngambil gambar si sub menunya -->
                <img src="<?= $ka['image']; ?>">
                <span><?= $ka['title'];
                            ?></span></a>
            </li>

        <?php endforeach; ?>

        <!-- Divider -->
        <hr class="sidebar-divider d-none d-md-block">

        <!-- Sidebar Toggler (Sidebar) -->
        <div class="text-center d-none d-md-inline">
            <button class="rounded-circle border-0" id="sidebarToggle"></button>
        </div>

</ul>
<!-- End of Sidebar -->