<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <meta name="google-signin-client_id" content="604959905252-8iip2ertuk6vtfv80aa2url6agovegq8.apps.googleusercontent.com">

    <title><?= $title; ?></title>

    <!-- Custom fonts for this template-->
    <link href="<?= base_url('assets/'); ?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="<?= base_url(); ?>/favicon.ico" rel="shortcut icon" type="image/ico" />

    <!-- Custom styles for this template-->
    <link href="<?= base_url('assets/'); ?>css/sb-admin-2.min.css" rel="stylesheet">

    <!-- google oauth -->
    <script src="https://apis.google.com/js/platform.js" async defer></script>

    <style>
        @import url('https://fonts.googleapis.com/css?family=Poppins&display=swap');
        @import url('https://fonts.googleapis.com/css?family=Muli:200&display=swap');

        a {
            color: #02925d;
            text-decoration: none;
            transition: 0.5s;

        }

        a:hover {
            transition: .5s;
            color: #fdcd64;
            text-decoration: none;
        }
    </style>


</head>

<body class="bg-white">