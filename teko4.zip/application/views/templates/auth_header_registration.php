<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?= $title; ?></title>

    <!-- Custom fonts for this template-->
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet" type="text/css">
    <!-- <link href="<= base_url('assets/'); ?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css"> -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link rel="stylesheet" href="<?= base_url('assets/'); ?>css/registration.css">
    <!-- <link href="<= base_url('assets/'); ?>css/sb-admin-2.min.css" rel="stylesheet"> -->

    <!-- JAVASCRIPT -->
    <script type="text/javascript">
        var client = Kinvey.init({
            appKey: 'kid_rk7NMn57z',
            appSecret: '3ecc483bd0864882b0c69965030961c6'
        });

        const heroRoleId = '0278b7bf-749f-453f-9b74-4a0b2afcfcff',
            villainRoleId = '1707214d-5c2f-436c-82d4-6e198749251d';

        // for the sake of simplicity in a sample app, I am always logging the current active user out when the page is loaded
        var promise = Kinvey.User.logout();

        // sign up a new user with Kinvey authentication
        document.getElementById('signup-button').addEventListener('click', function(event) {
            // If you want to validate these inputs before sending them to the backend you should do that here
            var user = new Kinvey.User();
            var promise = user.signup({
                    username: document.getElementById('email').value,
                    password: document.getElementById('password').value
                })
                .then(function(user) {
                    loginSuccess();
                    console.log(user);
                })
                .catch(function(error) {
                    // for the sake of simplicity, I'm just displaying any errors that the API sends me back
                    document.getElementById('error').innerHTML = error.message;
                });
        });

        // login using the Kinvey authentication
        document.getElementById('login-button').addEventListener('click', function(event) {
            var user = new Kinvey.User();
            var promise = user.login({
                    username: document.getElementById('email').value,
                    password: document.getElementById('password').value
                })
                .then(function(user) {
                    loginSuccess();
                    console.log(user);
                })
                .catch(function(error) {
                    document.getElementById('error').innerHTML = error.message;
                });
        });

        // sign up or log in with Google authentication
        document.getElementById('google-login').addEventListener('click', function(event) {
            var promise = Kinvey.User.loginWithMIC(window.location.href);
            promise.then(function onSuccess(user) {
                loginSuccess();
                console.log(user);
            }).catch(function onError(error) {
                document.getElementById('error').innerHTML = error.message;
            });
        });

        // log in an implicit user (i.e. anonymous) that defaults to the all users role
        document.getElementById('nosignin').addEventListener('click', function() {
            loginSuccess();
            document.getElementById('rolechooser').classList.add('fadeout');
            var promise = Kinvey.User.signup()
                .then(function(user) {
                    loadData();
                }).catch(function(error) {
                    console.log(error);
                });
        });

        // just in case, remove the other role first then pass the hero role id to assign the role
        document.getElementById('hero-button').addEventListener('click', function(event) {
            var userid = Kinvey.User.getActiveUser(client)._id,
                promise = Kinvey.CustomEndpoint.execute('deleteRole', {
                    userid: userid,
                    roleid: villainRoleId
                })
                .then(function(response) {
                    setRole(heroRoleId);
                })
                .catch(function(error) {
                    console.log(error);
                });
        });

        // // just in case, remove the other role first then pass the villain role id to assign the role
        document.getElementById('villain-button').addEventListener('click', function(event) {
            var userid = Kinvey.User.getActiveUser(client)._id,
                promise = Kinvey.CustomEndpoint.execute('deleteRole', {
                    userid: userid,
                    roleid: heroRoleId
                })
                .then(function(response) {
                    setRole(villainRoleId);
                })
                .catch(function(error) {
                    console.log(error);
                });

        });

        // change some styles when a user log in succeeds
        function loginSuccess() {
            var rolechooser = document.getElementById('rolechooser');

            document.getElementById('signup').classList.add('fadeout');
            document.getElementById('wrapper').classList.add('form-success');
            rolechooser.classList.remove('hidden');
            rolechooser.classList.add('fadein');
        }

        // set the user role via the REST API (not available in SDK at the moment)
        function setRole(roleid) {
            var userid = Kinvey.User.getActiveUser(client)._id,
                promise = Kinvey.CustomEndpoint.execute('addRole', {
                    userid: userid,
                    roleid: roleid
                })
                .then(function(response) {
                    console.log(response);
                    document.getElementById('rolechooser').classList.add('fadeout');
                    loadData();
                })
                .catch(function(error) {
                    console.log(error);
                });
        }

        // load data from 3 collections - one with all user access, one with hero only and one with villain only
        function loadData() {
            var ordinary_ds = Kinvey.DataStore.collection('ordinary-people'),
                heroes_ds = Kinvey.DataStore.collection('heroes'),
                villains_ds = Kinvey.DataStore.collection('villains');
            ordinary_ds.pull()
                .then(function(ordinaries) {
                    var el = document.getElementById('ordinaries-list'),
                        chrList = '';
                    ordinaries.forEach(function(ordinary) {
                        chrList += '<li>' + ordinary.name + '</li>';
                    });
                    el.innerHTML = chrList;
                    displayCharacters();
                })
                .catch(function(error) {
                    console.log(error);
                });
            heroes_ds.pull()
                .then(function(heroes) {
                    var el = document.getElementById('heroes-list'),
                        chrList = '';
                    heroes.forEach(function(hero) {
                        chrList += '<li>' + hero.hero_name + '</li>';
                    });
                    el.innerHTML = chrList;
                    displayCharacters();
                })
                .catch(function(error) {
                    console.log(error);
                    if (error.code == 401) {
                        var el = document.getElementById("heroes-list").innerHTML = '<li>Unauthorized</li>'
                    }
                });
            villains_ds.pull()
                .then(function(villains) {
                    var el = document.getElementById('villains-list'),
                        chrList = '';
                    villains.forEach(function(villain) {
                        chrList += '<li>' + villain.villain_name + '</li>';
                    });
                    el.innerHTML = chrList;
                    displayCharacters();
                })
                .catch(function(error) {
                    console.log(error);
                    if (error.code == 401) {
                        var el = document.getElementById("villains-list").innerHTML = '<li>Unauthorized</li>'
                    }
                });
        }

        // just a simple utility to determine if the lists are already displayed and display them
        function displayCharacters() {
            display = document.getElementById('display-characters');
            if (display.classList.contains('hidden')) {
                display.classList.remove('hidden');
                display.classList.add('fadein');
            }
        }
    </script>

    <!-- login facebook js -->

    <script>
        function statusChangeCallback(response) { // Called with the results from FB.getLoginStatus().
            console.log('statusChangeCallback');
            console.log(response); // The current login status of the person.
            if (response.status === 'connected') { // Logged into your webpage and Facebook.
                testAPI();
            } else { // Not logged into your webpage or we are unable to tell.
                document.getElementById('status').innerHTML = 'Please log ' +
                    'into this webpage.';
            }
        }


        function checkLoginState() { // Called when a person is finished with the Login Button.
            FB.getLoginStatus(function(response) { // See the onlogin handler
                statusChangeCallback(response);
            });
        }


        window.fbAsyncInit = function() {
            FB.init({
                appId: '{app-id}',
                cookie: true, // Enable cookies to allow the server to access the session.
                xfbml: true, // Parse social plugins on this webpage.
                version: '{api-version}' // Use this Graph API version for this call.
            });


            FB.getLoginStatus(function(response) { // Called after the JS SDK has been initialized.
                statusChangeCallback(response); // Returns the login status.
            });
        };


        (function(d, s, id) { // Load the SDK asynchronously
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s);
            js.id = id;
            js.src = "https://connect.facebook.net/en_US/sdk.js";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));


        function testAPI() { // Testing Graph API after login.  See statusChangeCallback() for when this call is made.
            console.log('Welcome!  Fetching your information.... ');
            FB.api('/me', function(response) {
                console.log('Successful login for: ' + response.name);
                document.getElementById('status').innerHTML =
                    'Thanks for logging in, ' + response.name + '!';
            });
        }
    </script>


</head>

<body class="bg-gradient-primary">