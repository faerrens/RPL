<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; TEKO RPL <?= date('Y'); ?></span>
        </div>
    </div>
</footer>
<!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal javascript-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Apakah kamu yakin untuk keluar?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Silakan klik "Logout" jika kamu ingin keluar.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-success" href="<?= base_url('authh/logout'); ?>">Logout</a>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap core JavaScript-->
<script src="<?= base_url('assets/'); ?>vendor/jquery/jquery.min.js"></script>
<script src="<?= base_url('assets/'); ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="<?= base_url('assets/'); ?>vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="<?= base_url('assets/'); ?>js/sb-admin-2.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>

<script>
    $('.custom-file-input').on('change', function() {
        let fileName = $(this).val().split('\\').pop();
        $(this).next('.custom-file-label').addClass("selected").html(fileName);
    });

    $('.form-check-input').on('click', function() {
        const menuId = $($this).data('menu');
        const roleId = $($this).data('role');
    });
</script>

<script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
</script>

<!-- <script>
    function onSignIn(googleUser) {
        var profile = googleUser.getBasicProfile();
        console.log('ID: ' + profile.getId()); // Do not send to your backend! Use an ID token instead.
        console.log('Name: ' + profile.getName());
        console.log('Image URL: ' + profile.getImageUrl());
        console.log('Email: ' + profile.getEmail()); // This is null if the 'email' scope is not present.
    }
</script> -->

<!-- < wp_enqueue_style('font-awesome-free', '//use.fontawesome.com/releases/v5.6.1/css/all.css'); ?> -->
<!-- <script type="text/javascript" src="https://use.fontawesome.com/releases/v5.11.2/js/conflict-detection.js">
</script> -->

<!-- searching ajax-->

<script type="text/javascript">
    $(document).ready(function() {
        $("$search").keyup(function() {
            var searchText = $(this).val();
            if (searchText != '') {
                $.ajax({
                    url: '<?= base_url('homepage/action'); ?>',
                    method: 'post',
                    data: {
                        query: searchText
                    },
                    success: function(response) {
                        $("#show-list").html(response);
                    }
                });
            } else {
                $("#show-list").html('');
            }
        });
        $(document).on('click', 'a', function() {
            $("#search").val($(this).text());
            $("#show-list").html('');
        });
    });
</script>

<script type="text/javascript">
    $('input.typeahead').typeahead({
        source: function(query, process) {
            return $.get('/action', {
                query: query
            }, function(data) {
                console.log(data);
                data = $.parseJSON(data);
                return process(data);
            });
        }
    });
</script>

<!-- search dari fikri -->

<script type="text/javascript">
    $(document).ready(function() {

        $('#title').autocomplete({
            source: "<?php echo site_url('homepage/get_autocomplete'); ?>",

            select: function(event, ui) {
                $(this).val(ui.item.label);
                $("#form_search").submit();
            }
        });

    });
</script>

<!-- <script src="<php echo base_url() . 'assets/js/jquery-ui.js' ?>" type="text/javascript"></script> -->
<!-- <script src="?php echo base_url() . 'assets/js/jquery-3.3.1.js' ?>" type="text/javascript"></script> -->
<!-- <script src="?php echo base_url() . 'assets/js/bootstrap.js' ?>" type="text/javascript"></script> -->

</body>

</html>